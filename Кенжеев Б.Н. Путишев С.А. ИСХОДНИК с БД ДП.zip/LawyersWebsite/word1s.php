<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета на выезд для юридического лица (по решению суда).docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$adresssud = $_POST['adresssud'];
$date = $_POST['date'];
$nameorg = $_POST['nameorg'];
$uradress = $_POST['uradress'];
$bin = $_POST['bin'];
$number = $_POST['number'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('adresssud', $adresssud);
$document->setValue('date', $date);
$document->setValue('nameorg', $nameorg);
$document->setValue('uradress', $uradress);
$document->setValue('bin', $bin);
$document->setValue('number', $number);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета на выезд для юридического лица (по решению суда)' . $nameorg . '_full.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
