<?php
include "config.php";

if(isset($_POST['request_id']) && isset($_POST['sogl_status'])) {
    $request_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $sogl_status = mysqli_real_escape_string($conn, $_POST['sogl_status']);

    // SQL запрос для обновления статуса консультации
    $sql_update = "UPDATE ConsultationRequests SET Agreements = '$sogl_status' WHERE id = $request_id";

    if(mysqli_query($conn, $sql_update)){
        // Обновление выполнено успешно
        // После успешного выполнения запроса к базе данных
        echo '<script>alert("Статус соглашения успешно сохранен."); window.location.href = "lawyerPanel.php";</script>';

    } else{
        // Ошибка при выполнении запроса
        echo "ERROR: Не удалось выполнить запрос. " . mysqli_error($conn);
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
}
?>