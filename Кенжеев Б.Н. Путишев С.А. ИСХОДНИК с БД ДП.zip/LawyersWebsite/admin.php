<?php
include "config.php";
session_start();
if($_SESSION['role']==1){
$user_id=$_SESSION['uId'];

if(isset($user_id)){?>
  <!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Admin</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

  <body>
     <!-- ======= Header ======= -->
     <header id="header">
    <div class="d-flex flex-column">
    <?php
$select = mysqli_query($conn,"SELECT * FROM registration WHERE  usrID = '$user_id'") or die('query failed');
if(mysqli_num_rows($select) > 0){
   $fetch = mysqli_fetch_assoc($select);
}  
?>
      <div class="profile">
        <img src="images2/<?php echo $fetch['lawyer_photograph']?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><?php echo $fetch['usrName']?></h1>
        <div class="social-links mt-3 text-center">
          <a href="www.twitter.com" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="www.facebook.com" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="www.instagram.com" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="www.google.com" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="www.linkedin.com" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="home.php" class="nav-link scrollto "><i class="bx bx-home"></i> <span>На главную страницу сайта</span></a></li>
          <li><a href="#hero" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Главная</span></a></li>
          <li><a href="lawyers.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Юристы</span></a></li>
          <li><a href="users.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Пользователи</span></a></li>
          <li><a href="appointment.php" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Консультации</span></a></li>
          <li><a href="updateadmin.php" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Обновление профиля</span></a></li>
          <li><a href="Logout.php" class="nav-link scrollto"><i class="bx bx-log-out"></i> <span>Выход</span></a></li>

        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
  <section style="background:url('images2/image_6.jpg')  top center " id="hero" class="d-flex flex-column justify-content-center align-items-center">
  
    <div class="hero-container" data-aos="fade-in">
      <h1><?php echo $fetch['usrName']?></h1>
      <p>Добро пожаловать в <span class="typed" data-typed-items="Админ панель"></span></p>
    </div>
  </section>

  <main id="main">

 
      <!-- ======= Facts Section ======= -->
      <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Статистика</h2>
        </div>

        <div class="row no-gutters">

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up">
            <div class="count-box">
              <i class="bi bi-emoji-smile"></i>
              <?php
              $query="SELECT usrID FROM registration where roleid=3 ORDER BY usrID";
              $query_run=mysqli_query($conn,$query);
              $count=mysqli_num_rows($query_run);
              
              echo '<span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
             '; ?>
              <p><strong>Всего клиентов</strong></p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <?php
              $query="SELECT id FROM appointments where status='Done' ORDER BY id";
              $query_run=mysqli_query($conn,$query);
              $count=mysqli_num_rows($query_run);
              
             echo ' <span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
             '; ?>
              <p><strong>Выполненно консультаций</strong> </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="200">
            <div class="count-box">
              <i class="bi bi-headset"></i>
              <span data-purecounter-start="0" data-purecounter-end="1453" data-purecounter-duration="1" class="purecounter"></span>
              <p><strong>Количество часов работ с клиентами</strong> </p>
            </div>
          </div>

          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="300">
            <div class="count-box">
              <i class="bi bi-people"></i>
              <?php
               $query="SELECT usrID FROM registration where roleid=2 ORDER BY usrID";
               $query_run=mysqli_query($conn,$query);
               $count=mysqli_num_rows($query_run);
              echo'
              <span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
             ';?>
              <p><strong>Юристы</strong> </p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Facts Section -->



    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Заявки</h2>
        </div>

        <table class="table ">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">О заявке</th>
      <th scope="col">Действие</th>

    </tr>
  </thead>
  <tbody>
<?php
  $sql = "SELECT * FROM ConsultationRequests";
  $result = mysqli_query($conn, $sql);
  $counter = 1; // Начальное значение счетчика
  while ($row = mysqli_fetch_array($result)) {
    
      echo '<tr>
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td><a href="fullinfouser copy.php?id=' . $row['id'] . '" class="button-style" >Подробнее</a></td>
                <td>
                  
                 
                
                  <form action="assign_lawyer.php" method="post">
                  <input type="hidden" name="request_id" value="'.$row['id'].'">
                  <select name="lawyer_name" class="select-container">
                      <option value="">Выберите юриста</option>';
                      // Получить список имен юристов из таблицы registration
                      $sql_lawyers = "SELECT usrName FROM registration WHERE roleid = 2";
                      $result_lawyers = mysqli_query($conn, $sql_lawyers);
                      while ($lawyer = mysqli_fetch_assoc($result_lawyers)) {
                          echo '<option value="'.$lawyer['usrName'].'">'.$lawyer['usrName'].'</option>';
                      } 
                  echo '</select><br>
                  <button type="submit" class="button-style">Назначить</button>
                  <a href="delete_request.php?id='.$row['id'].'" class="buttonn" onclick="return confirm(\'Вы уверены, что хотите удалить эту заявку?\')">Удалить</a>
                </form>
                </td>
                     
            </tr>';    
            $counter++; // Увеличиваем значение счетчика на каждой итерации

  }
?>

  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->

    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Заявки с юристами</h2>
        </div>

        <table class="table ">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">О заявке</th>
      <th scope="col">Назначенный юрист</th>
      <th scope="col">Доп. документы</th>
    </tr>
  </thead>
  <tbody>
  <?php
  $sql = "SELECT * FROM ConsultationRequests";
  $result = mysqli_query($conn, $sql);
  $counter = 1; // Начальное значение счетчика
  while ($row = mysqli_fetch_array($result)) {
    
      echo '<tr>               
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td><a href="fullinfouser copy.php?id=' . $row['id'] . '" class="button-style"  >Подробнее</a></td>
                <td>'.$row['lawyer_name'].'</td>
                <td><a href="' . $row['photograph'] . '" class="button-style"  >' . $row['photograph'] . '</a></td>
    </tr>';    $counter++; // Увеличиваем значение счетчика на каждой итерации

  }?>
  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->






    <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>С нами связались</h2>
        </div>

        <table class="table ">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">Направление</th>
      <th scope="col">Сообщение</th>
      <th scope="col">Действие</th>

    </tr>
  </thead>
  <tbody>
  <?php
  $sql="SELECT * FROM contact";
  $result=mysqli_query($conn,$sql);
     $counter = 1; // Начальное значение счетчика
  while($row=mysqli_fetch_array($result)){
 
  echo '        
    <tr>
    <td>'.$counter.'</td>
    <td>'.$row['name'].'</td>
    <td>'.$row['email'].'</td>
    <td>'.$row['subject'].'</td>
      <td>'.$row['message'].'</td>
     <td> <a href="deletecon.php?id='.$row['id'].'" class="buttonn">Удалить</a> </td>
    </tr>';
    $counter++; // Увеличиваем значение счетчика на каждой итерации

  }?>
  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->


</main>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/typed.js/typed.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>
</html>
      
<?php
}}
else{
    header("location:404 Not found.html");
}?>


<style>
  
  .table>tbody>tr:nth-child(even) {
    background-color: #f2f2f2;
}
.table>tbody>tr:nth-child(even) {
    background-color: #f2f2f2;
}



  .select-container {
    position: relative;
    width: 200px;
}

.select-container select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #fff;
    font-size: 16px;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    cursor: pointer;
}

.select-container::after {
    content: '\25BC'; /* символ стрелочки вниз */
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    pointer-events: none;
}

/* При фокусе */
.select-container select:focus {
    outline: none;
    border-color: #007bff;
}

/* При наведении */
.select-container select:hover {
    border-color: #007bff;
}


.buttonn {
  
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: #FF4B2B;

    
}

.buttonn:active {
	transform: scale(0.95);
}

.buttonn:focus {
	outline: none;
}

.buttonn:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
.button-style {
  margin-top: 5px;    
	border-radius: 10px;
	border: 1px solid green;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: green;
  text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}

.button-style:hover {
    background-color: green;
    border: 1px solid green;
    text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}


.button-stylel {
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    color: #333;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 14px;
}

.button-stylel:hover {
    background-color: red;
    border: 1px solid red;
}
.container2 {
  position: relative;
  width: 11.5%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-55%, -45%);
  text-align: center;
  width:80%;
  height:80%;
}

.container2:hover .image {
  opacity: 0.3;
}

.container2:hover .middle {
  opacity: 0.7;
}

.text {
  background-color: #04AA6D;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
  
}
#hero {
  width: 120%;
  height: 49vh;
  background:  top center;
  background-size: cover;
}

#hero:before {
  content: "";
  background: rgba(255, 255, 255, 0.3);
  position: absolute;
  bottom: 0;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
}
</style>


