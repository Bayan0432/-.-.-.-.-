<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LawyerDetails</title>
    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" 
  rel="stylesheet"  type='text/css'>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</head>
<body>


   
   <div class="container">

   <form class="well form-horizontal" method="post" id="contact_form" enctype="multipart/form-data" novalidate="novalidate">
    <fieldset>

        <!-- Form Name -->
        <legend><center><h2><b>Добро пожаловать на регистрацию юриста!</b></h2></center></legend><br>

        <div class="form-group">
            <label class="col-md-4 control-label"> Имя</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="usrName" placeholder="Введите имя" class="form-control" type="text" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Email</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="email" placeholder="Email" class="form-control" type="email" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Пароль</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="pass" placeholder="Введите пароль" class="form-control" type="password" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label"> Квалификация</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="qualf" placeholder="Введите свою квалификацию" class="form-control" type="text" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label" > Адрес</label> 
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="add" placeholder="Введите свои адрес" class="form-control" type="text" required>
                </div>
            </div>
        </div>

        <div class="form-group"> 
            <label class="col-md-4 control-label">Ваше направление</label>
            <div class="col-md-4 selectContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                    <select name="dep" class="form-control">
                        <option selected value="">Выберите ваше направление</option>
                        <?php 
                        include "config.php";
                        $sql="Select * From Departments";
                        $result=mysqli_query($conn,$sql);
                        while($row=mysqli_fetch_array($result)){
                        ?>
                        <option value="<?php echo $row["depName"]?>"><?php echo $row["depName"]?></option>
                        <?php } ?>
                    </select>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Дата рождения</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                    <input name="dob" placeholder="Введите дату рождения" class="form-control" type="date" value="date(Y-m-d)" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Номер телефона</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                    <input name="phone" placeholder="(+7)" class="form-control" type="text" required>
                </div>
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">Загрузите ваш аватар</label>  
            <div class="col-md-4 inputGroupContainer">
                <div class="input-group">
                    <span class="input-group-addon"><i class="fa fa-camera"></i></span>
                    <input type="file" name="lawyer_photograph" class="form-control">
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-md-4 col-md-offset-4">
                <input type="submit" name="lawSubmit" value="Завершить регистрацию!" class="btn btn-primary">
            </div>
        </div>

    </fieldset>
</form>

</div>
</div><!-- /.container -->
</body>
</html>
<?php
if(isset($_POST["lawSubmit"])){
    $name = $_POST['usrName'];
    $email = $_POST['email'];
    $pwd = $_POST['pass'];
    $qualf = $_POST['qualf'];
    $add = $_POST['add'];  
    $dep = $_POST['dep'];
    $dob = $_POST['dob']; 
    $ph = $_POST['phone']; 
    $img_name = isset($_FILES['lawyer_photograph']['name']) ? $_FILES['lawyer_photograph']['name'] : ''; // Имя файла
    $img_tmp_name = isset($_FILES['lawyer_photograph']['tmp_name']) ? $_FILES['lawyer_photograph']['tmp_name'] : ''; // Временное имя файла

    // Проверяем, был ли загружен файл
    if(!empty($img_name) && !empty($img_tmp_name)) {
        $accept = ['jpeg','jpg','png','webp','jfif','gif','tiff'];
        $to_lowerCase = strtolower(pathinfo($img_name, PATHINFO_EXTENSION));
        // Проверяем, соответствует ли тип файла допустимым расширениям
        if(in_array($to_lowerCase, $accept)) {
            // Перемещаем файл в нужную директорию
            move_uploaded_file($img_tmp_name, "images2/".$img_name);
        } else {
            echo "ERROR: Недопустимый формат файла.";
            exit;
        }
    }

    // Выполняем запрос к базе данных
    include "config.php";
    $email = $_POST['email'];
    // Проверяем, существует ли пользователь с таким email
    $sql_check_email = "SELECT * FROM registration WHERE Email = ?";
    $stmt_check_email = mysqli_prepare($conn, $sql_check_email);
    mysqli_stmt_bind_param($stmt_check_email, "s", $email);
    mysqli_stmt_execute($stmt_check_email);
    $result_check_email = mysqli_stmt_get_result($stmt_check_email);

    if(mysqli_num_rows($result_check_email) > 0) {
        echo "Пользователь с таким email уже существует.";
    } else {
        // Вставляем новую запись в таблицу
        $sql = "INSERT INTO registration (usrName, Email, Pass, Qualification, Address, DepName, dob, phNo, lawyer_photograph, blobimage, roleid)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, '2')";
        $stmt = mysqli_prepare($conn, $sql);
        if ($stmt) {
            // Define $blobimage variable if needed
            $blobimage = ''; // Replace this with your blobimage logic if necessary
            
            // Bind parameters
            mysqli_stmt_bind_param($stmt, "ssssssssss", $name, $email, $pwd, $qualf, $add, $dep, $dob, $ph, $img_name, $blobimage);
            
            // Execute statement
            if (mysqli_stmt_execute($stmt)) {
                // Success, redirect
                echo '<script>alert("Данные успешно добавлены в базу данных."); window.location.href = "login.php";</script>';
                exit;
            } else {
                // Error in execution
                echo "ERROR: " . mysqli_stmt_error($stmt);
            }
        } else {
            // Error in prepare
            echo "ERROR: " . mysqli_error($conn);
        }

        // Close statement and connection
        mysqli_stmt_close($stmt);
    }

    mysqli_close($conn);
}
?>





<style>
.container{
margin-top: 2%;
width:70%;
}
@mixin sp-layout {
  @media screen and (max-width: 750px) {
    @content;
  }
}

body {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 100vh;
   background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
  overflow: hidden;
}

.button {
    margin-left:35%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;

}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);

}

.profile-pic {
    width: 200px;
    max-height: 200px;
    display: inline-block;
}

.file-upload {
    display: none;
}
.circle {
    border-radius: 100% !important;
    overflow: hidden;
    width: 128px;
    height: 128px;
    border: 2px solid rgba(255, 255, 255, 0.2);
    position: absolute;
    top: 72px;
}
img {
    max-width: 100%;
    height: auto;
}
.p-image {
  position: absolute;
  top: 167px;
  right: 30px;
  color: #666666;
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.p-image:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.upload-button {
  font-size: 1.2em;
}

.upload-button:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}
</style>
<script>
    $(document).ready(function() {

    
var readURL = function(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.profile-pic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".file-upload").on('change', function(){
    readURL(this);
});

$(".upload-button").on('click', function() {
   $(".file-upload").click();
});
});
</script>


