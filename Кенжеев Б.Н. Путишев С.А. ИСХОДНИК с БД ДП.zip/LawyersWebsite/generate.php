<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <style> body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
}

.categories {
    display: flex;
    justify-content: center;
    
    padding: 20px;
}

.category {
    background-color: #f0f0f0;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    margin: 10px;
    padding: 20px;
    width: 300px;
}

.category h2 {
    color: #333;
    font-size: 1.2em;
    margin-top: 0;
}

.subcategory-list {
    list-style-type: none;
    padding: 0;
}

.subcategory {
    margin-top: 10px;
}

.subcategory button {
    background-color: #afa939;
    border: none;
    color: white;
    padding: 10px 20px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 16px;
    cursor: pointer;
    border-radius: 5px;
    transition: background-color 0.3s;
}

.subcategory button:hover {
    background-color: #afa910;
}
 </style>
</head>
<body>

<div class="categories">
    <div class="category">
        <h2>Банкротство</h2>
        <ul class="subcategory-list">
            <li class="subcategory"><a href="Заявление о банкротсве(физ).php"><button>Заявление о банкротсве (юр-лицо)</button></a></li>
            <li class="subcategory"><a href="Заявление о признании должника банкротом(юр.лиц).php"><button>Заявление о признании должника банкротом(юр.лиц)</button></a></li>
            <li class="subcategory"><a href="Заявление в арбитражный суд о банкротстве  (юр-лиц).php"><button>Заявление в арбитражный суд о банкротстве  (юр-лиц)</button></a></li>
            <li class="subcategory"><a href="Аппеляционная жалоба(физ-лицо).php"><button>Аппеляционная жалоба(физ-лицо)</button></a></li>
            <li class="subcategory"><a href="Аппеляционная жалоба (юридическое лицо).php"><button>Аппеляционная жалоба (юридическое лицо)</button></a></li>
        </ul>
    </div>
    <div class="category">
        <h2>Снятие запрета на выезд</h2>
        <ul class="subcategory-list">
            <li class="subcategory"><a href="Снятие запрета на выезд для физических лиц .php"><button>Снятие запрета на выезд для физических лиц </button></a></li>
            <li class="subcategory"><a href="Снятие запрета на выезд для юридического лица (по решению суда).php"><button>Снятие запрета на выезд для юридического лица (по решению суда)</button></a></li>
            <li class="subcategory"><a href="Снятие временного запрета на выезд для физических лиц (по причинам).php"><button>Снятие временного запрета на выезд для физических лиц (по причинам)</button></a></li>
            <li class="subcategory"><a href="Снятие запрета на выезд для несовершенного.php"><button>Снятие запрета на выезд для несовершенного</button></a></li>
            <li class="subcategory"><a href="Заявление о снятии запрета на выезд за границу для лица, участвующего в уголовном процессе.php"><button>Заявление о снятии запрета на выезд за границу для лица, участвующего в уголовном процессе</button></a></li>
        </ul>
    </div>
    <div class="category">
        <h2>Снятие ареста со счетов</h2>
        <ul class="subcategory-list">
            <li class="subcategory"><a href="Снятие запрета со счета физического лица.php"><button>Снятие запрета со счета физического лица</button></a></li>
            <li class="subcategory"><a href="Снятие запрета со счета юридического лица (для долга перед банком).php"><button>Снятие запрета со счета юридического лица (для долга перед банком)</button></a></li>
            <li class="subcategory"><a href="Снятие запрета с физического лица (по решению суда).php"><button>Снятие запрета с физического лица (по решению суда)</button></a></li>
            <li class="subcategory"><a href="Снятие запрета с юридического лица (по решению суда).php"><button>Снятие запрета с юридического лица (по решению суда)</button></a></li>
            <li class="subcategory"><a href="Снятие запрета с физического лица (по истечении срока).php"><button>Снятие запрета с физического лица (по истечении срока)</button></a></li>
        </ul>
    </div>
    <div class="category">
        <h2>График МФО</h2>
        <ul class="subcategory-list">
            <li class="subcategory"><a href="Заявление об урегулировании задолженности в МФО юр-лиц.php"><button>Заявление об урегулировании задолженности в МФО юр-лиц</button></a></li>
            <li class="subcategory"><a href="Заявление об урегулировании задолженности в МФО физ-лицо .php"><button>Заявление об урегулировании задолженности в МФО физ-лицо </button></a></li>
            <li class="subcategory"><a href="Запрос об остатке задолженности в МФО юр-лицо (1).php"><button>Запрос об остатке задолженности в МФО юр-лицо (1)</button></a></li>
            <li class="subcategory"><a href="Запроса для физического лица к микрофинансовой организации (МФО).php"><button>Запроса для физического лица к микрофинансовой организации (МФО)</button></a></li>
            <li class="subcategory"><a href="Запрос для юридического лица к микрофинансовой организации (МФО).php"><button>Запрос для юридического лица к микрофинансовой организации (МФО)</button></a></li>
        </ul>
    </div>
</div>
<a href="lawyerPanel.php"  class="button">Вернуться в кабинет</a>
</body>
</html>
<style>
    .button {
    margin-left:40%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;
    margin-top: 10px;
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
</style>