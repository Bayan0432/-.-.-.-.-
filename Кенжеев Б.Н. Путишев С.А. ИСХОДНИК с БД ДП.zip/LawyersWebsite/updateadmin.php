<?php

include 'config.php';
session_start();
if($_SESSION['role']==1){

$user_id = $_SESSION['uId'];

if(isset($_POST['update_profile'])){

   $update_name = mysqli_real_escape_string($conn, $_POST['update_name']);
   $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);



   mysqli_query($conn, "UPDATE registration SET usrName = '$update_name', email = '$update_email' where usrID='$user_id'");
   $old_pass = $_POST['old_pass'];
   $update_pass = $_POST['update_pass'];
   $new_pass =$_POST['new_pass'];
   $confirm_pass = $_POST['confirm_pass'];

   if(!empty($update_pass) || !empty($new_pass) || !empty($confirm_pass)){
      if($update_pass != $old_pass){
         $message[] = 'old password not matched!';
      }elseif($new_pass != $confirm_pass){
         $message[] = 'confirm password not matched!';
      }else{
         mysqli_query($conn, "UPDATE registration SET Pass = '$confirm_pass' WHERE usrID = '$user_id'") or die('query failed');
         $message[] = 'password updated successfully!';
      }
   }

   $update_image = $_FILES['update_image']['name'];
   $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
   $update_image_folder = 'images2/'.$update_image;

   if(!empty($update_image)){
         $image_update_query = mysqli_query($conn, "UPDATE registration SET lawyer_photograph = '$update_image' WHERE usrID = '$user_id'") or die('query failed');
         if($image_update_query){
            move_uploaded_file($update_image_tmp_name, $update_image_folder);
         }
         $message[] = 'image updated succssfully!';
      }
   }



?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>update profile</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style2.css">
   <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<!-- Vendor CSS Files -->
<link href="assets/vendor/aos/aos.css" rel="stylesheet">
<link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
<link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
<link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
<link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
<link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
<link href="assets/css/style.css" rel="stylesheet">
</head>
<body>
<header id="header">
    <div class="d-flex flex-column">
    <?php
$select = mysqli_query($conn,"SELECT * FROM registration WHERE usrID='$user_id'") or die('query failed');
if(mysqli_num_rows($select) > 0){
   $fetch = mysqli_fetch_assoc($select);
}  
?>
      <div class="profile">
        <img src="images2/<?php echo $fetch['lawyer_photograph']?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><?php echo $fetch['usrName']?></h1>
        <div class="social-links mt-3 text-center">
          <a href="www.twitter.com" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="www.facebook.com" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="www.instagram.com" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="www.google.com" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="www.linkedin.com" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="#hero" class="nav-link scrollto "><i class="bx bx-home"></i> <span>Главная</span></a></li>
          <li><a href="lawyers.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Юристы</span></a></li>
          <li><a href="users.php" class="nav-link scrollto"><i class="bx bx-user"></i> <span>Пользователи</span></a></li>
          <li><a href="appointment.php" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Консультации</span></a></li>
          <li><a href="updateadmin.php" class="nav-link scrollto active"><i class="bx bx-file-blank"></i> <span>Обновления профиля</span></a></li>
          <li><a href="Logout.php" class="nav-link scrollto"><i class="bx bx-log-out"></i> <span>Выход</span></a></li>

        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
<div class="update-profile">

   <?php
      $select = mysqli_query($conn, "SELECT * FROM registration WHERE usrID = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select) > 0){
         $fetch = mysqli_fetch_assoc($select);
      }
   ?>

   <form  method="post" enctype="multipart/form-data" class="form">
      <?php
         if($fetch['lawyer_photograph'] == ''){
            echo '<img src="images/default-avatar.png">';
         }else{
            echo '<img src="images2/'.$fetch['lawyer_photograph'].'">';
         }
         if(isset($message)){
            foreach($message as $message){
               echo '<div class="message">'.$message.'</div>';
            }
         }
      ?>
      <div class="flex">
         <div class="inputBox">
            <span>Имя:</span>
            <input type="text" name="update_name" value="<?php echo $fetch['usrName']; ?>" class="box">
            <span>email :</span>
            <input type="email" name="update_email" value="<?php echo $fetch['Email']; ?>" class="box">
            <span>обновление аватара :</span>
            <input type="file" name="update_image" accept="lawyer_photograph/jpeg,lawyer_photograph/jpg,lawyer_photograph/png,lawyer_photograph/webp,lawyer_photograph/jfif,lawyer_photograph/gif,lawyer_photograph/tiff"
             class="box">
         </div>
         <div class="inputBox">
            <input type="hidden" name="old_pass" value="<?php echo $fetch['Pass']; ?>">
            <span>старый пароль :</span>
            <input type="password" name="update_pass" placeholder="enter previous password" class="box">
            <span>новый пароль :</span>
            <input type="password" name="new_pass" placeholder="enter new password" class="box">
            <span>подтвердите пароль :</span>
            <input type="password" name="confirm_pass" placeholder="confirm new password" class="box">
         </div>
 </select>     
    </div>
    <input type="submit" value="Обновить профиль" name="update_profile" class="btn">
      <a href="admin.php" class="delete-btn">Назад</a>
      </div>
      
   </form>

</div>

</body>
</html>

<?php }
else{
   header("location:404 Not found.html");
}?>