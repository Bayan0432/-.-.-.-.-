<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Victory</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>
  <body>



  <?php
session_start();
include "config.php";

// Check if the user is logged in
if(isset($_SESSION['uId'])) {
    $user_id = $_SESSION['uId'];
    $user_name = $_SESSION['username'];
    
    // Fetch user role from the database
    $sql = "SELECT roleid FROM registration WHERE usrID = $user_id";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $user_role = $row['roleid'];
    } else {
        // If unable to fetch role, assume a default role or handle error
        $user_role = 0; // Default role, for example
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a href="home.php" class="nav-link">Главная</a></li>
                <li class="nav-item"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Услуги</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
                <?php if(isset($_SESSION['uId'])) { ?>
                    <!-- Navigation items for logged-in users -->
                    <li class="nav-item"><a href="logout.php" class="nav-link">Выход</a></li>
                    <!-- Add other navigation items based on user role -->
                    <?php if ($user_role == 1) { ?>
                        <li class="nav-item"><a href="admin.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                    <?php } elseif ($user_role == 2) { ?>
                        <li class="nav-item"><a href="lawyerPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                    <?php } elseif ($user_role == 3) { ?>
                        <li class="nav-item"><a href="userPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                    <?php } ?>
                <?php } else { ?>
                    <!-- Navigation items for non-logged-in users -->
                    <li class="nav-item"><a href="Register.php" class="nav-link">Регистрация</a></li>
                    <li class="nav-item"><a href="login.php" class="nav-link">Войти</a></li>
                <?php } ?>
            </ul>
        </div>
    </div>
</nav>

<!-- Rest of your HTML content goes here -->

      <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Контакты</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Главная <i class="ion-ios-arrow-forward"></i></a></span> <span>Контакты <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
    <?php
  include "config.php";
  session_start();
  if(isset($_SESSION['uId'])) {
		$user_id = $_SESSION['uId'];
		$user_name = $_SESSION['username'];
	
    $select = mysqli_query($conn,"SELECT * FROM registration WHERE usrID = '$user_id'") or die('query failed');
    if(mysqli_num_rows($select) > 0){
       $fetch = mysqli_fetch_assoc($select);
    }  
    ?>
   	<section class="ftco-section contact-section">
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h3">Контактная информация</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3">
            <p><span>Адрес:</span> Петропавловск, Ул. Имени Евнея Букетова, Д. 53, Кв. 31.</p>
          </div>
          <div class="col-md-3">
            <p><span>Телефон:</span> <a href="tel://1234567920">+7 705 123 65 34</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Email:</span> <a href="mailto:info@yoursite.com">Victory@gmail.com</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Сайт</span> <a href="#">Victory.com</a></p>
          </div>
        </div>
        <div class="row block-9 no-gutters">
          <div class="col-lg-6 order-md-last d-flex">
            <form method="post" class="bg-light p-5 contact-form">
              <div class="form-group">
                <input type="text" class="form-control" value="<?php echo $fetch['usrName']?>" name="name">
              </div>
              <div class="form-group">
                <input type="text" class="form-control" value="<?php echo $fetch['Email']?>" name="email" >
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Направнение услуги" name="sub">
              </div>
              <div class="form-group">
                <textarea name="msg" id="" cols="30" rows="7" class="form-control" placeholder="Сообщение"></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Отправить сообщение" class="btn btn-primary py-3 px-5" name="submit">
              </div>
            </form>
          
          </div>

          <div class="col-lg-6 d-flex">
  <a href="https://2gis.kz/petropavlovsk/firm/70000001084112782?m=69.139389%2C54.87295%2F16.64" target="_blank">
    <img src="images/map.png" class="img-fluid" alt="Map Image">
  </a>
</div>
        </div>
      </div>
    </section>


 
    
<?php 
}
else{?>
    	  
      
   	
   	<section class="ftco-section contact-section">
      <div class="container">
        <div class="row d-flex mb-5 contact-info">
          <div class="col-md-12 mb-4">
            <h2 class="h3">Контактная информация</h2>
          </div>
          <div class="w-100"></div>
          <div class="col-md-3">
            <p><span>Адрес:</span> Петропавловск, Ул. Имени Евнея Букетова, Д. 53, Кв. 31.</p>
          </div>
          <div class="col-md-3">
            <p><span>Телефон:</span> <a href="tel://1234567920">+ 1235 2355 98</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Email:</span> <a href="mailto:info@yoursite.com">Victory@gmail.com</a></p>
          </div>
          <div class="col-md-3">
            <p><span>Сайт</span> <a href="#">Victory.com</a></p>
          </div>
        </div>
        <div class="row block-9 no-gutters">
          <div class="col-lg-6 order-md-last d-flex">
            <form method="post" class="bg-light p-5 contact-form">
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Ваше имя" name="name" required>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Ваш Email"name="email" required>
              </div>
              <div class="form-group">
                <input type="text" class="form-control" placeholder="Subject" name="sub" required>
              </div>
              <div class="form-group">
                <textarea name="msg" id="" cols="30" rows="7" class="form-control" placeholder="Message" required></textarea>
              </div>
              <div class="form-group">
                <input type="submit" value="Отправить сообщение" class="btn btn-primary py-3 px-5" name="submit">
              </div>
            </form>
          
          </div>

          <div class="col-lg-6 d-flex">
  <a href="https://2gis.kz/petropavlovsk/firm/70000001084112782?m=69.139389%2C54.87295%2F16.64" target="_blank">
    <img src="images/map.png" class="img-fluid" alt="Map Image">
  </a>
</div>
        </div>
      </div>
    </section>




<?php 
}?>




























  
	 
    
    


      
    <!-- END nav -->
    
   
  
    
    
<?php include 'footer.php'  ?>


  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>

<?php

if(isset($_POST["submit"])){
    $name=$_POST['name'];
    $email=$_POST['email'];

    $sub=$_POST['sub'];
    $msg=$_POST['msg'];

   
 $sql="insert into contact(name,email,subject,message)
 values('$name','$email','$sub','$msg')";
 $result=mysqli_query($conn,$sql);
 if(!$sql){
     echo"Something Went Wrong";
 }
 else{
    echo "<script>alert('Thanks For Contacting Us!')</script>";
}
}
?>

<style>
  .img-fluid {
  max-width: 100%;
  height: 66%;
  margin-top: 70px;
}
</style>