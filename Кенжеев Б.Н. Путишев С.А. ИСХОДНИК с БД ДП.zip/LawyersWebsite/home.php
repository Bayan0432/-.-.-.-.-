<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Victory</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
 <!-- Google Web Fonts -->
 <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@400;600&family=Roboto:wght@300;500;700&display=swap" rel="stylesheet"> 

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">



    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">


</head>
<body>
<?php
session_start();
if(isset($_SESSION['uId'])) {
    $user_id = $_SESSION['uId'];
    $user_name = $_SESSION['username'];
    
    // Подключение к базе данных
    include "config.php";
    
    // Получение роли пользователя из базы данных
    $sql = "SELECT roleid FROM registration WHERE usrID = $user_id";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $user_role = $row['roleid'];
    } else {
        // Если не удалось получить роль, предполагаем роль по умолчанию или обрабатываем ошибку
        $user_role = 0; // Например, роль по умолчанию - 0
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
?>

<nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a href="home.php" class="nav-link">Главная</a></li>
                <li class="nav-item"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Услуги</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
				<li class="nav-item"><a href="logout.php" class="nav-link">Выход</a></li>
                <?php if ($user_role == 1) { ?>
                    <li class="nav-item"><a href="admin.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } elseif ($user_role == 2) { ?>
                    <li class="nav-item"><a href="lawyerPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } elseif ($user_role == 3) { ?>
                    <li class="nav-item"><a href="userPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } ?>
                
            </ul>
        </div>
    </div>
</nav>

<?php } else { ?>
<nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item active"><a href="home.php" class="nav-link">Главная</a></li>
                <li class="nav-item"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Услуги</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
                <li class="nav-item "><a href="Register.php" class="nav-link">Регистрация</a></li>
                <li class="nav-item "><a href="login.php" class="nav-link">Войти</a></li>
            </ul>
        </div>
    </div>
</nav>
<?php } ?>

	
	


	
    <div class="hero-wrap js-fullheight" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text js-fullheight align-items-center justify-content-start" data-scrollax-parent="true">
          <div class="col-md-6 ftco-animate">
          	<h2 class="subheading">Добро пожаловать в Victory</h2>
          	<h1>Окажем юридические услуги 
						  <span
						     class="txt-rotate"
						     data-period="2000"
						     data-rotate='[ "Банкротство.", "Снятие ареста со счетов.", "Снятие запрета на выезд.", "МФО." ]'></span>
						</h1>
            <!-- <h1 class="mb-4">Attorneys Fighting For Your Freedom</h1> -->
            <p class="mb-4">Мы помогли сотням людей решить юридические проблемы. Теперь они доверяют юристам Victory</p>
            <p><a href="base.php" class="btn btn-primary mr-md-4 py-2 px-4">Отправить заявку <span class="ion-ios-arrow-forward"></span></a></p>
          </div>
        </div>
      </div>
    </div>

            <!-- Why Select Us -->

    <section class="ftco-section ftco-no-pt">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-3 py-5">
	          <div class="heading-section ftco-animate">
	          	<span class="subheading">Услуги</span>
	            <h2 class="mb-4">Почему Вы выбрали именно Нас?</h2>
	            <p>Мы предоставляем все необходимые вам услуги, у нас есть лучшие юристы с 10-летним опытом, которые доступны для вас 24 часа в сутки!!</p>
	            <p><a href="attorneys.php" class="btn btn-primary py-3 px-4">Обратится за консультацией</a></p>
	          </div>
    			</div>
    			<div class="col-lg-9 services-wrap px-4 pt-5">
    				<div class="row pt-md-3">
    					<div class="col-md-4 d-flex align-items-stretch">
		    				<div class="services text-center">
		    					<div class="icon d-flex justify-content-center align-items-center">
		    						<span class="flaticon-lawyer"></span>
		    					</div>
		    					<div class="text">
		    						<h3>Бороться за справедливость</h3>
		    						<p>Стремление к справедливости в мире требует от нас значительных эмоциональных вложений, когда мы следуем этому призыву.</p>
		    					</div>
		    				</div>
		    			</div>
		    			<div class="col-md-4 d-flex align-items-stretch">
		    				<div class="services text-center">
		    					<div class="icon d-flex justify-content-center align-items-center">
		    						<span class="flaticon-lawyer"></span>
		    					</div>
		    					<div class="text">
		    						<h3>Наилучшая стратегия в данном случае</h3>
		    						<p>Наши Лучшие Юристы Предложат Вам Наилучшую Стратегию Ведения Дела, Которая Позволит Вам Легко решить ваши проблемы</p>
		    					</div>
		    				</div>
		    			</div>
		    			<div class="col-md-4 d-flex align-items-stretch">
		    				<div class="services text-center">
		    					<div class="icon d-flex justify-content-center align-items-center">
		    						<span class="flaticon-lawyer"></span>
		    					</div>
		    					<div class="text">
		    						<h3>Опытный юрист</h3>
		    						<p>Наши Опытные Юристы Предоставляют Вам Услуги В Течение 24 Часов В Сутки!</p>
		    					</div>
		    				</div>
		    			</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>

            <!-- Experience -->

   	
    <section class="ftco-section ftco-no-pt ftco-no-pb">
    	<div class="container">
    		<div class="row d-flex">
    			<div class="col-md-6 d-flex">
    				<div class="img img-video d-flex align-self-stretch align-items-center justify-content-center justify-content-md-end" style="background-image:url(images/about.jpg);">
    					
    				</div>
    			</div>
    			<div class="col-md-6 pl-md-5">
    				<div class="row justify-content-start pt-3 pb-3">
		          <div class="col-md-12 heading-section ftco-animate">
		          	<span class="subheading">Добро пожаловать в Victory</span>
		            <h2 class="mb-4">Мы всегда боремся за то, чтобы все ваши проблемы были решены</h2>
		            <p>Ваша Проблема - Это Наша Проблема, Мы Предоставляем Надежные И Эффективные Юридические Услуги!!!</p>
		            <div class="tabulation-2 mt-4">
									<ul class="nav nav-pills nav-fill d-md-flex d-block">
									  <li class="nav-item mb-md-0 mb-2">
									    <a class="nav-link active py-2" data-toggle="tab" href="#home1">Наша миссия</a>
									  </li>
									  <li class="nav-item px-lg-2 mb-md-0 mb-2">
									    <a class="nav-link py-2" data-toggle="tab" href="#home2">Наше видение</a>
									  </li>
									  <li class="nav-item">
									    <a class="nav-link py-2 mb-md-0 mb-2" data-toggle="tab" href="#home3">Наша ценность</a>
									  </li>
									</ul>
									<div class="tab-content bg-light rounded mt-2">
									  <div class="tab-pane container p-0 active" id="home1">
									  	<p>Наша Миссия - Обеспечить Справедливость Для Тех, Кто в Ней Нуждается!</div>
									  <div class="tab-pane container p-0 fade" id="home2">
									  	<p>Наше Видение Состоит в том, чтобы Устранить ваши проблемы И Обеспечить Справедливость Для Всех.</p>
									  </div>
									  <div class="tab-pane container p-0 fade" id="home3">
									  	<p>Мы Позаботимся О Том, Чтобы Наши юристы Разработали Для Вас Наилучшую Стратегию Ведения Дела!.</p>
									  </div>
									</div>
								</div>
		            <div class="years d-flex mt-4 mt-md-5">
		            	<h4>
			            	<span class="number mr-2" >10</span>
				            <span>летний юридический опыт</span>
			            </h4>
		            </div>
		          </div>
		        </div>
	        </div>
        </div>
    	</div>
    </section>



    <br><br><br><br>
        <!-- servicess -->
    <section class="ftco-section ftco-no-pt">
    	<div class="container">
    		<div class="row">
    			<div class="col-lg-3 py-5">
	          <div class="heading-section ftco-animate">
	          	<span class="subheading">Наши услуги</span>
	            <h2 class="mb-4">Основные направления</h2>
	            <p>Мы предоставляем все необходимые вам услуги, у нас есть лучшие юристы , которые доступны для вас 24 часа в сутки!!</p>
	            <p><a href="services.php" class="btn btn-primary py-3 px-4">Смотреть все услуги</a></p>
	          </div>
    			</div>
    			<div class="col-lg-9 services-wrap px-4 pt-5">
    				<div class="row pt-md-3">
    					<div class="col-md-4 d-flex align-items-stretch">
                        <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                            <div class="icon-box bg-secondary text-primary mt-2 mb-4">
                                <a href="familylaw.php"><i class="fa fa-2x fa-users"></i></a>
                            </div>
                            <h5 class="mb-4 px-4">Банкротство</h5>
                            <p class="m-0">Банкротство — это юридическая процедура, при которой физическое или юридическое лицо объявляется неспособным погасить свои долги перед кредиторами.</p>
                        </div>
		    			</div>
                        
		    			<div class="col-md-4 d-flex align-items-stretch">
                            <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                            <div class="icon-box bg-secondary text-primary mt-2 mb-4">
							<a href="bus.php"><i class="fa fa-2x fa-hand-holding-usd"></i></a>
                            </div>
                            <h5 class="mb-4 px-4">Снятие ареста со счетов</h5>
                            <p class="m-0">Снятие ареста со счета - это процедура, при которой юридические ограничения на использование средств на счете снимаются. </p>
                        </div>
		    			</div>
		    			<div class="col-md-4 d-flex align-items-stretch">
                            <div class="d-flex flex-column align-items-center text-center bg-white rounded pt-4">
                            <div class="icon-box bg-secondary text-primary mt-2 mb-4">
							<a href="crim.php">  <i class="fa fa-2x fa-gavel"></i></a>
                            </div>
                            <h5 class="mb-4 px-4">Снятие запрета на выезд</h5>
                            <p class="m-0">Снятие запрета на выезд обычно означает прекращение ограничений, которые ранее были наложены на человека, запрещая ему покидать определенную территорию, страну или регион. </p>
                        </div>
						
		    				</div>
		    			</div>
    				</div>
    			</div>
    		</div>
    	</div>
    </section>



   
		        <!-- Client Review -->

    <section class="ftco-section testimony-section">
      <div class="container">
        <div class="row justify-content-center mb-5">
          <div class="col-md-7 text-center heading-section ftco-animate">
          	<span class="subheading">Комментарии</span>
            <h2 class="mb-4">Довольные клиенты</h2>
          </div>
        </div>
        <div class="row ftco-animate">
          <div class="col-md-12">
            <div class="carousel-testimony owl-carousel ftco-owl">
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Получил грамотную консультацию , что помогло мне спокойно выехать за границу.</p>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(images/person_1.jpg)"></div>
                    	<div class="pl-3">
		                    <p class="name">Иван Абрамов</p>
		                    <span class="position">Маркетолог</span>
		                  </div>
	                  </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Класс!!! очень быстро оформил банкротство всем советую Victory.Круто что есть такие юридические центры!</p>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(images/person_2.jpg)"></div>
                    	<div class="pl-3">
		                    <p class="name">Олег Иванов</p>
		                    <span class="position">Бухгалтер</span>
		                  </div>
	                  </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">В последнее время было много проблем с МФО, не знал что делать,друг посоветовал Victory.</p>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(images/person_3.jpg)"></div>
                    	<div class="pl-3">
		                    <p class="name">Махмуд Ибраев</p>
		                    <span class="position">Бизнесмен</span>
		                  </div>
	                  </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Запретили выезжать за границу ,жена на Бали - так не пойдет.Хорошо Victory помог. </p>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(images/person_1.jpg)"></div>
                    	<div class="pl-3">
		                    <p class="name">Андрей Краснов</p>
		                    <span class="position">Премьер-министр</span>
		                  </div>
	                  </div>
                  </div>
                </div>
              </div>
              <div class="item">
                <div class="testimony-wrap py-4">
                  <div class="text">
                    <p class="mb-4">Заблокировали все счета , не знал что делать ,друг посоветовал вас ,не подвели.Спасибо!</p>
                    <div class="d-flex align-items-center">
                    	<div class="user-img" style="background-image: url(images/person_2.jpg)"></div>
                    	<div class="pl-3">
		                    <p class="name">Евкакий Олегов</p>
		                    <span class="position">Водитель</span>
		                  </div>
	                  </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

   
		


        <!-- Footer -->

<?php include 'footer.php'  ?>
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>