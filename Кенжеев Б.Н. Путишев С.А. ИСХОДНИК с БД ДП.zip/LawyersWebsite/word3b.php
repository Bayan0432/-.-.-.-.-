<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Заявление в арбитражный суд о банкротстве  (юр-лиц).docx');

// Обработка данных из формы
$adressud = $_POST['adressud'];
$namesudi = $_POST['namesudi'];
$zaiavitel = $_POST['zaiavitel'];
$adresszaiavitel = $_POST['adresszaiavitel'];
$organ = $_POST['organ'];
$dolznic = $_POST['dolznic'];
$name = $_POST['name']; // Добавили переменную name
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('adressud', $adressud);
$document->setValue('namesudi', $namesudi);
$document->setValue('zaiavitel', $zaiavitel);
$document->setValue('adresszaiavitel', $adresszaiavitel);
$document->setValue('organ', $organ);
$document->setValue('dolznic', $dolznic);
$document->setValue('name', $name); // Добавили замену для переменной name

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Заявление в арбитражный суд о банкротстве  (юр-лиц)_' . $zaiavitel . '_full.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
