<?php

include 'config.php';
session_start();
if($_SESSION['role']==2){

$user_id = $_SESSION['uId'];

if(isset($_POST['update_profile'])){

   $update_name = mysqli_real_escape_string($conn, $_POST['update_name']);
   $update_email = mysqli_real_escape_string($conn, $_POST['update_email']);
   $update_qualification = mysqli_real_escape_string($conn, $_POST['update_qualification']);
   $update_address = mysqli_real_escape_string($conn, $_POST['update_address']);
   $update_deb = mysqli_real_escape_string($conn, $_POST['update_deb']);
   $update_dob = mysqli_real_escape_string($conn, $_POST['update_dob']);
   $update_ph = mysqli_real_escape_string($conn, $_POST['update_ph']);



   mysqli_query($conn, "UPDATE registration SET usrName = '$update_name', email = '$update_email'
   ,Qualification='$update_qualification'
   ,Address='$update_address',DepName='$update_deb',dob='$update_dob',phNo='$update_ph' WHERE usrID = '$user_id'") or die('query failed');

   $old_pass = $_POST['old_pass'];
   $update_pass = $_POST['update_pass'];
   $new_pass =$_POST['new_pass'];
   $confirm_pass = $_POST['confirm_pass'];

   if(!empty($update_pass) || !empty($new_pass) || !empty($confirm_pass)){
      if($update_pass != $old_pass){
         $message[] = 'old password not matched!';
      }elseif($new_pass != $confirm_pass){
         $message[] = 'confirm password not matched!';
      }else{
         mysqli_query($conn, "UPDATE registration SET Pass = '$confirm_pass' WHERE usrID = '$user_id'") or die('query failed');
         $message[] = 'password updated successfully!';
      }
   }

   $update_image = $_FILES['update_image']['name'];
   $update_image_tmp_name = $_FILES['update_image']['tmp_name'];
   $update_image_folder = 'images2/'.$update_image;

   if(!empty($update_image)){
         $image_update_query = mysqli_query($conn, "UPDATE registration SET lawyer_photograph = '$update_image' WHERE usrID = '$user_id'") or die('query failed');
         if($image_update_query){
            move_uploaded_file($update_image_tmp_name, $update_image_folder);
         }
         $message[] = 'image updated succssfully!';
      }
   }



?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>update profile</title>

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style2.css">

</head>
<body>
   
<div class="update-profile">

   <?php
      $select = mysqli_query($conn, "SELECT * FROM registration WHERE usrID = '$user_id'") or die('query failed');
      if(mysqli_num_rows($select) > 0){
         $fetch = mysqli_fetch_assoc($select);
      }
   ?>

   <form  method="post" enctype="multipart/form-data" class="form">
      <?php
         if($fetch['lawyer_photograph'] == ''){
            echo '<img src="images/default-avatar.png">';
         }else{
            echo '<img src="images2/'.$fetch['lawyer_photograph'].'">';
         }
         if(isset($message)){
            foreach($message as $message){
               echo '<div class="message">'.$message.'</div>';
            }
         }
      ?>
      <div class="flex">
         <div class="inputBox">
            <span>Имя :</span>
            <input type="text" name="update_name" value="<?php echo $fetch['usrName']; ?>" class="box">
            <span>email :</span>
            <input type="email" name="update_email" value="<?php echo $fetch['Email']; ?>" class="box">
            <span>обновите аватар :</span>
            <input type="file" name="update_image" accept="lawyer_photograph/jpeg,lawyer_photograph/jpg,lawyer_photograph/png,lawyer_photograph/webp,lawyer_photograph/jfif,lawyer_photograph/gif,lawyer_photograph/tiff"
             class="box">
         </div>
         <div class="inputBox">
            <input type="hidden" name="old_pass" value="<?php echo $fetch['Pass']; ?>">
            <span>старый пароль :</span>
            <input type="password" name="update_pass" placeholder="enter previous password" class="box">
            <span>новый пароль :</span>
            <input type="password" name="new_pass" placeholder="enter new password" class="box">
            <span>подтвердите пароль :</span>
            <input type="password" name="confirm_pass" placeholder="confirm new password" class="box">
         </div>
         <div class="inputBox">
         <span>Квалификация :</span>
            <input type="text" name="update_qualification" value="<?php echo $fetch['Qualification']; ?>" class="box">
            <span>Адрес:</span>
            <input type="text" name="update_address" placeholder="enter new password" value="<?php echo $fetch['Address']; ?>" class="box">
            <span>Направление :</span>
              <select name="update_deb" class="box">
    <option selected value=""><?php echo $fetch['DepName']; ?></option>
<?php 
$sql="Select * From departments";
$result=mysqli_query($conn,$sql);
while($row=mysqli_fetch_array($result)){
    ?>
     <option value="<?php echo $row["depName"]?>"><?php echo $row["depName"]?></option>
 <?php } ?>
 </select>     
    </div>
    <div class="inputBox">
            <span>Date Of Birth :</span>
            <input type="date" name="update_dob" value="<?php echo $fetch['dob']; ?>" class="box">
            <span>Phone No :</span>
            <input type="text" name="update_ph" value="<?php echo $fetch['phNo']; ?>" class="box">
            
         </div>
      </div>
      <input type="submit" value="Обновление профиля" name="update_profile" class="btn">
      <a href="lawyerPanel.php" class="delete-btn">Назад</a>
   </form>

</div>

</body>
</html>

<?php }
else{
   header("location:404 Not found.html");
}?>