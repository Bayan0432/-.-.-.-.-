<?php
include "config.php";

if(isset($_POST['request_id']) && isset($_POST['consultation_status'])) {
    $request_id = mysqli_real_escape_string($conn, $_POST['request_id']);
    $consultation_status = mysqli_real_escape_string($conn, $_POST['consultation_status']);

    // SQL запрос для обновления статуса консультации
    $sql_update = "UPDATE ConsultationRequests SET Agreements = '$consultation_status' WHERE id = $request_id";

    if(mysqli_query($conn, $sql_update)){
        // Обновление выполнено успешно
        echo '<script>alert("Статус успешно обновлен."); window.location.href = "userPanel.php";</script>';
    } else{
        // Ошибка при выполнении запроса
        echo "ERROR: Не удалось выполнить запрос. " . mysqli_error($conn);
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
}
?>