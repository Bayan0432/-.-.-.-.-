<?php

include "config.php";
$id = $_GET['id'];
$sql = "UPDATE appointments  set status='Завершено' where id = '$id'";
$result=mysqli_query($conn,$sql);
header("location:lawyerPanel.php");
?>