<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lawyers Profile</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

  <body>
<?php
  include "config.php";
  session_start();
  if($_SESSION['role']==2){

  $user_id=$_SESSION['uId'];
  $user_name=$_SESSION['username'];
  if(isset($user_id)){?>
      <!-- ======= Header ======= -->
    <header id="header">
      <div class="d-flex flex-column">
      <?php
  $select = mysqli_query($conn,"SELECT * FROM registration WHERE usrID = '$user_id'") or die('query failed');
  if(mysqli_num_rows($select) > 0){
    $fetch = mysqli_fetch_assoc($select);
}  
?>
      <div class="profile">
        <img src="images2/<?php echo $fetch['lawyer_photograph']?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><?php echo $fetch['usrName']?></h1>
        <div class="social-links mt-3 text-center">
          <a href="www.twitter.com" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="www.facebook.com" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="www.instagram.com" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="www.google.com" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="www.linkedin.com" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="home.php" class="nav-link scrollto "><i class="bx bx-home"></i> <span>На главную страницу сайта</span></a></li>
          <li><a href="#about" class="nav-link scrollto active"><i class="bx bx-user"></i> <span>О мне</span></a></li>
          <li><a href="#Заявкивожидании" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Заявки в ожидании</span></a></li>
          <li><a href="#Принятыезаявки" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Принятые заявки</span></a></li>
          <li><a href="#Завершенныезаявки" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Завершенные заявки</span></a></li>
          <li><a href="update_profile.php" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Обновление профиля</span></a></li>
          <li><a href="generate.php" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Генерация документа</span></a></li>
          <li><a href="Logout.php" class="nav-link scrollto"><i class="bx bx-log-out"></i> <span>Выход</span></a></li>

        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
  <section style="background:url('images2/image_3.jpg') top center" id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1><?php echo $fetch['usrName']?></h1>
      <p>Добро пожаловать на <span class="typed" data-typed-items="Юридическую панель"></span></p>
    </div>
  </section>

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about">
      <div class="container">

        <div class="section-title">
          <h2>О мне</h2>
        </div>

        <div class="row">
          <div class="col-lg-4" data-aos="fade-right">
            <img src="images2/<?php echo $fetch['lawyer_photograph']?>" class="img-fluid" alt="">
          </div>
          <div class="col-lg-8 pt-4 pt-lg-0 content" data-aos="fade-left">
           
            <div class="row">
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Дата рождения:</strong> <span><?php echo $fetch['dob']?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Телефон:</strong> <span><?php echo $fetch['phNo']?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Город:</strong> <span><?php echo $fetch['Address']?></span></li>
                </ul>
              </div>
              <div class="col-lg-6">
                <ul>
                  <li><i class="bi bi-chevron-right"></i> <strong>Юридическая степень:</strong> <span><?php echo $fetch['Qualification']?></span></li>
                  <li><i class="bi bi-chevron-right"></i> <strong>Email:</strong> <span><?php echo $fetch['Email']?></span></li>
                            <li><i class="bi bi-chevron-right"></i> <strong>Статус:</strong> <span>В работе</span></li>
                </ul>
            </div>
            </div>
           
          </div>
        </div>

      </div>
    </section><!-- End About Section -->
      <!-- ======= Facts Section ======= -->
      <section id="facts" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Статистика</h2>
        </div>

        <div class="row no-gutters">

          
        <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up">
          <div class="count-box">
            <i class="bi bi-emoji-smile"></i>
            <?php
              $query="SELECT lawyer_id FROM ConsultationRequests where Statuszayavki ='Завершено' And lawyer_name='$user_name' ORDER BY lawyer_id";
              $query_run=mysqli_query($conn,$query);
              $count=mysqli_num_rows($query_run);    
            
            echo'<span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
            ';?>
            <p><strong>Завершенные заявки</strong></p>
          </div>
        </div>






<div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <?php
                $query="SELECT lawyer_id FROM ConsultationRequests where  lawyer_name='$user_name' ORDER BY lawyer_id";
                $query_run=mysqli_query($conn,$query);
                $count=mysqli_num_rows($query_run);    
            
              echo'<span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
              ';?>
                            <p><strong>Всего заявок</strong> </p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <?php
                $query="SELECT lawyer_id FROM ConsultationRequests where Statuszayavki ='Принят' And lawyer_name='$user_name' ORDER BY lawyer_id";
                $query_run=mysqli_query($conn,$query);
                $count=mysqli_num_rows($query_run);    
            
              echo'<span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
              ';?>
                            <p><strong>Принято заявок</strong> </p>
            </div>
          </div>
          <div class="col-lg-3 col-md-6 d-md-flex align-items-md-stretch" data-aos="fade-up" data-aos-delay="100">
            <div class="count-box">
              <i class="bi bi-journal-richtext"></i>
              <?php
                $query="SELECT lawyer_id FROM ConsultationRequests where Statuszayavki ='В ожидании' And lawyer_name='$user_name' ORDER BY lawyer_id";
                $query_run=mysqli_query($conn,$query);
                $count=mysqli_num_rows($query_run);    
            
              echo'<span data-purecounter-start="0" data-purecounter-end="'.$count.'" data-purecounter-duration="1" class="purecounter"></span>
              ';?>
                            <p><strong>Всего заявок в ожидании</strong> </p>
            </div>
          </div>
        </div>




      </div>
      </section><!-- End Facts Section -->


    <section id="Заявкивожидании" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Заявки в ожидании </h2>
        </div>

        <table class="table table-white">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">Направление</th>
      <th scope="col">Телефон</th>
      <th scope="col">Физ. лицо</th>
      <th scope="col">Юр. лицо</th>
      <th scope="col">Описание проблемы</th>
      <th scope="col">Доп. документы</th>
      <th scope="col">Статус заявки</th>
      <th scope="col">Действия</th>
    </tr>
  </thead>
  <tbody>
<?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests WHERE lawyer_id = '$user_id' AND Statuszayavki ='В ожидании'";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
  // Вывод результатов
  while ($row = mysqli_fetch_assoc($result)) {
      echo '<tr>
              <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['dep'].'</td>
                <td>'.$row['phone'].'</td>
                <td>'.$row['legal_entity'].'</td>
                <td>'.$row['individual'].'</td>
                <td>'.$row['problem_description'].'</td>
                <td><a href="' . $row['photograph'] . '"><button class="button-style"> '. $row['photograph'] .'</button></a></td>
                <td>'.$row['Statuszayavki'].'</td>
                <td> <a href="markk.php?id='.$row['id'].'" ><button class="button-style"> Принять заявку</button></a> </td>             
            </tr>';
            $counter++; // Увеличиваем значение счетчика на каждой итерации

    }
} else {
    echo "Заявки в ожидании отсутствуют.";
}
?>

  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->






    <section id="App" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Косультации в ожидании</h2>
        </div>

        <table class="table">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">Дата консультации</th>
      <th scope="col">Время консультации</th>
      <th scope="col">Направление</th>
      <th scope="col">Статус</th>
      

    </tr>
  </thead>
  <tbody>
  <?php
        $sql="SELECT * FROM appointments where lawname='$user_name' AND status='Принято'";
        $result=mysqli_query($conn,$sql); $counter = 1; // Начальное значение счетчика
        while($row=mysqli_fetch_array($result)){
        
  echo '        
    <tr>
    <td>'.$counter.'</td>
    <td>'.$row['usrName'].'</td>
    <td>'.$row['email'].'</td>
    <td>'.$row['date'].'</td>
      <td>'.$row['time'].'</td>
      <td>'.$row['service'].'</td>
      <td>'.$row['status'].'</td>
    </tr>'; 
    $counter++; // Увеличиваем значение счетчика на каждой итерации

  }?>
  </tbody>
</table>
</section>


<section id="Принятыезаявки" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Принятые заявки</h2>
        </div>
<div class="container">

    <table class="table ">
      <thead>
        <tr>
          <th scope="col">№</th>
          <th scope="col">Имя клиента</th>
          <th scope="col">О заявке</th>
          <th scope="col">Консультации</th>
          <th scope="col">Генерация документа</th>
          <th scope="col">Формулирование согл.</th>
          <th scope="col">Статус</th>
        </tr>
      </thead>

    <tbody>
    <?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests WHERE lawyer_id = '$user_id' AND Statuszayavki ='Принят'";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
  // Вывод результатов
    while ($row = mysqli_fetch_assoc($result)) {
        $consultation_status = ''; // Инициализируем переменную статуса консультации
        if ($row['Consultations']) {
            // Если значение статуса консультации уже сохранено в базе данных, сохраняем его в переменную
            $consultation_status = $row['Consultations'];
        } else {
            // Если значение статуса консультации еще не сохранено, отображаем выпадающий список
            $consultation_status = '
            <form method="post" action="save_consultation_status.php">
                <input type="hidden" name="request_id" value="'.$row['id'].'">
                <div >
                    <select name="consultation_status" class="select-container" >
                        <option value="Не проведена">Не проведена</option>
                        <option value="Проведена">Проведена</option>
                    </select>
                </div>
                <button type="submit" class="button-style">Сохранить</button><br>
                <a href="formcoft.php?id=' .$row['id'].'"   >Назначить консультацию</a>
            </form>';
        }

        $doc_status = ''; // Инициализация переменной статуса документа

          if ($row['Document_generation']) {
              // Если значение статуса документа уже сохранено в базе данных, сохраняем его в переменную
              $doc_status = $row['Document_generation'];
          } else {
              // Если значение статуса документа еще не сохранено, отображаем форму для назначения юриста и кнопку "Сохранить"
              $doc_status = '
              <form action="assign_document.php" method="post">
                  <input type="hidden" name="request_id" value="'.$row['id'].'"   >
                  <select name="lawyer_name" class="select-container" >
                      <option value="" class="">Выберите сгенерированный документ</option>';
                      // Получить список имен юристов из таблицы generated_files
                      $sql_lawyers = "SELECT file_link FROM generated_files WHERE lawyer_id = '$user_id'";
                      $result_lawyers = mysqli_query($conn, $sql_lawyers);
                      while ($lawyer = mysqli_fetch_assoc($result_lawyers)) {
                          $doc_status .= '<option value="'.$lawyer['file_link'].'">'.$lawyer['file_link'].'</option>';
                      }
                  $doc_status .= '</select><br>
                  <a href="generate.php"class="button-style"> Создать документ</a>
                  <button type="submit" class="button-style">Сохранить</button>
                  
              </form>';
          }
        echo '<tr>
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td><a href="fullinfouser.php?id=' . $row['id'] . '" class="button-style"  >Подробнее</a></td>
                <td> '.$consultation_status.'</td>
                </td>
                <td>'.$doc_status.'</td>
                <td>'.$row['Agreements'].'</td>
                <td> <a href="markkk.php?id='.$row['id'].'" > <button class="buttonn">   Завершить заявку </button>   </a> </td>
              </tr>';
              $counter++; // Увеличиваем значение счетчика на каждой итерации

    }
} else {
    echo "Нет принятых заявок, связанных с текущим юристом.";
}
?>


  </tbody>
</table>
      
    </div>
  </div>
  
      
        </div>
      </div>
    </section><!-- End Facts Section -->


  




  <section id="Завершенныезаявки" class="facts">
      <div class="container">

        <div class="section-title">
          <h2>Завершенные заявки</h2>
        </div>

  <table class="table table-white">
    <thead>
      <tr>
        <th scope="col">№</th>
        <th scope="col">Имя клиента</th>
        <th scope="col">Email клиента</th>
        <th scope="col">Направление</th>
        <th scope="col">Телефон</th>
        <th scope="col">Физ. лицо</th>
        <th scope="col">Юр. лицо</th>
        <th scope="col">Описание проблемы</th>
        <th scope="col">Статус заявки</th>
      </tr>
    </thead>
  <tbody>
<?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests WHERE lawyer_id = '$user_id'AND Statuszayavki ='Завершено'";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
  // Вывод результатов
  while ($row = mysqli_fetch_assoc($result)) {
      echo '<tr>
              <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['dep'].'</td>
                <td>'.$row['phone'].'</td>
                <td>'.$row['legal_entity'].'</td>
                <td>'.$row['individual'].'</td>
                <td>'.$row['problem_description'].'</td>
                <td>'.$row['Statuszayavki'].'</td>
              </tr>';
              $counter++; // Увеличиваем значение счетчика на каждой итерации
         
    }
} else {
    echo "Нет заявок, связанных с текущим юристом.";
}
?>
  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->







  
</main>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/typed.js/typed.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>
</html>
      
<?php
}}
else{
    header("location:404 Not found.html");
}?>


   

   	




 
   
	
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>







<style>
.table>tbody>tr:nth-child(even) {
    background-color: #f2f2f2;
}



  .select-container {
    position: relative;
    width: 100%;
}

.select-container select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #fff;
    font-size: 16px;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    cursor: pointer;
}

.select-container::after {
    content: '\25BC'; /* символ стрелочки вниз */
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    pointer-events: none;
}

/* При фокусе */
.select-container select:focus {
    outline: none;
    border-color: #007bff;
}

/* При наведении */
.select-container select:hover {
    border-color: #007bff;
}


.buttonn {
  
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: #FF4B2B;

    
}

.buttonn:active {
	transform: scale(0.95);
}

.buttonn:focus {
	outline: none;
}

.buttonn:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
.button-style {
  margin-top: 5px;    
	border-radius: 10px;
	border: 1px solid green;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: green;
  text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}

.button-style:hover {
    background-color: green;
    border: 1px solid green;
    text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}


.button-stylel {
    background-color: #f0f0f0;
    border: 1px solid #ccc;
    color: #333;
    padding: 5px 10px;
    cursor: pointer;
    border-radius: 3px;
    font-size: 14px;
}

.button-stylel:hover {
    background-color: red;
    border: 1px solid red;
}

.container2 {
  position: relative;
  width: 11.5%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-55%, -45%);
  text-align: center;
  width:80%;
  height:80%;
}

.container2:hover .image {
  opacity: 0.3;
}

.container2:hover .middle {
  opacity: 0.7;
}

.text {
  background-color: #04AA6D;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
  
}



/* Style the dropdown menu */
.consultation-select {
  width: 75%;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f8f8f8;
  cursor: pointer;
  outline: none;
}

/* Style the dropdown menu options */
.consultation-select option {
  padding: 10px;
}

/* Style the dropdown menu when hovered */
.consultation-select:hover {
  background-color: #e0e0e0;
}

/* Style the dropdown menu when focused */
.consultation-select:focus {
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}



#hero {
  width: 120%;
  height: 49vh;
  background:  top center;
  background-size: cover;
}

#hero:before {
  content: "";
  background: 0;
  position: absolute;
  bottom: 0;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
}
</style>




