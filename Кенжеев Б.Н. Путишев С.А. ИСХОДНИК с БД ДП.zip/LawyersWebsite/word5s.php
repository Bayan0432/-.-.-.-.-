<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Заявление о снятии запрета на выезд за границу для лица, участвующего в уголовном процессе.docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$adressud = $_POST['adressud'];
$date = $_POST['date'];
$ctovygolov = $_POST['ctovygolov'];
$chto = $_POST['chto'];
$name = $_POST['name'];
$daterojd = $_POST['daterojd'];
$mestorojd = $_POST['mestorojd'];
$adressreg = $_POST['adressreg'];
$iin = $_POST['iin'];
$passportdan = $_POST['passportdan'];
$vashidoki = $_POST['vashidoki'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('adressud', $adressud);
$document->setValue('date', $date);
$document->setValue('ctovygolov', $ctovygolov);
$document->setValue('chto', $chto);
$document->setValue('name', $name);
$document->setValue('daterojd', $daterojd);
$document->setValue('mestorojd', $mestorojd);
$document->setValue('adressreg', $adressreg);
$document->setValue('iin', $iin);
$document->setValue('passportdan', $passportdan);
$document->setValue('vashidoki', $vashidoki);

// Сохраняем прикрепленные файлы
$targetDir = "uploads/";
$uploadedFiles = [];
foreach ($_FILES['files']['name'] as $key => $name) {
    $targetFilePath = $targetDir . basename($_FILES['files']['name'][$key]);
    if (move_uploaded_file($_FILES['files']['tmp_name'][$key], $targetFilePath)) {
        $uploadedFiles[] = $targetFilePath;
    }
}

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Заявление о снятии запрета на выезд за границу для лица, участвующего в уголовном процессе_' . $name . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
