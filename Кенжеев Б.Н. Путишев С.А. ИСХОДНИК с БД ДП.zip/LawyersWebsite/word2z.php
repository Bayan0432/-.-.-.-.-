<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета со счета юридического лица (для долга перед банком).docx');

// Обработка данных из формы
$namebank = $_POST['namebank'];
$adresbank = $_POST['adresbank'];
$date = $_POST['date'];
$numchet = $_POST['numchet'];
$prichinazapr = $_POST['prichinazapr'];
$name = $_POST['name'];
$uradress = $_POST['uradress'];
$iin = $_POST['iin'];
$ogrn = $_POST['ogrn'];
$tel = $_POST['tel'];
$lico = $_POST['lico'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namebank', $namebank);
$document->setValue('adresbank', $adresbank);
$document->setValue('date', $date);
$document->setValue('numchet', $numchet);
$document->setValue('prichinazapr', $prichinazapr);
$document->setValue('name', $name);
$document->setValue('uradress', $uradress);
$document->setValue('iin', $iin);
$document->setValue('ogrn', $ogrn);
$document->setValue('tel', $tel);
$document->setValue('lico', $lico);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета со счета юридического лица (для долга перед банком)' . $namebank . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
