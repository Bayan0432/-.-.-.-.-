<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Lawyers Profile</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

</head>

  <body>
<?php
  include "config.php";
  session_start();
  if($_SESSION['role']==3){

  $user_id=$_SESSION['uId'];
  $user_name=$_SESSION['username'];
  if(isset($user_id)){?>
      <!-- ======= Header ======= -->
    <header id="header">
      <div class="d-flex flex-column">
      <?php
  $select = mysqli_query($conn,"SELECT * FROM registration WHERE usrID = '$user_id'") or die('query failed');
  if(mysqli_num_rows($select) > 0){
    $fetch = mysqli_fetch_assoc($select);
}  
?>
      <div class="profile">
        <img src="images2/<?php echo $fetch['lawyer_photograph']?>" alt="" class="img-fluid rounded-circle">
        <h1 class="text-light"><?php echo $fetch['usrName']?></h1>
        <div class="social-links mt-3 text-center">
          <a href="www.twitter.com" class="twitter"><i class="bx bxl-twitter"></i></a>
          <a href="www.facebook.com" class="facebook"><i class="bx bxl-facebook"></i></a>
          <a href="www.instagram.com" class="instagram"><i class="bx bxl-instagram"></i></a>
          <a href="www.google.com" class="google-plus"><i class="bx bxl-skype"></i></a>
          <a href="www.linkedin.com" class="linkedin"><i class="bx bxl-linkedin"></i></a>
        </div>
      </div>

      <nav id="navbar" class="nav-menu navbar">
        <ul>
          <li><a href="home.php" class="nav-link scrollto active"><i class="bx bx-home"></i> <span>Главная</span></a></li>
          <li><a href="#Заявкивожидании" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Заявки в ожидании</span></a></li>
          <li><a href="#Заявкипринятыеюристом" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Заявки принятые юристом</span></a></li>
          <li><a href="#Сгенерированныйдокументотюриста" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Сгенерированный документ<br> от юриста</span></a></li>
          <li><a href="#Завершенныезаявки" class="nav-link scrollto"><i class="bx bx-file-blank"></i> <span>Завершенные заявки</span></a></li>
          <li><a href="Logout.php" class="nav-link scrollto"><i class="bx bx-log-out"></i> <span>Выход</span></a></li>

        </ul>
      </nav><!-- .nav-menu -->
    </div>
  </header><!-- End Header -->
  <section style="background:url('images2/image_3.jpg') top center" id="hero" class="d-flex flex-column justify-content-center align-items-center">
    <div class="hero-container" data-aos="fade-in">
      <h1><?php echo $fetch['usrName']?></h1>
      <p>Добро пожаловать в <span class="typed" data-typed-items="Личный кабинет"></span></p>
    </div>
  </section>

  <main id="main">


    <section id="Заявкивожидании" class="facts contet">
      <div class="container">

        <div class="section-title">
          <h2>Заявки в ожидании </h2>
        </div>

        <table class="table">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">Направление</th>
      <th scope="col">Телефон</th>
      <th scope="col">Физ. лицо</th>
      <th scope="col">Юр. лицо</th>
      <th scope="col">Описание проблемы</th>
      <th scope="col">Доп. документы</th>
      <th scope="col">Статус заявки</th>
    </tr>
  </thead>
  <tbody>
<?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests where usrName='$user_name' AND Statuszayavki='В ожидании' ";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
    // вывод результатов
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['dep'].'</td>
                <td>'.$row['phone'].'</td>
                <td>'.$row['legal_entity'].'</td>
                <td>'.$row['individual'].'</td>
                <td>'.$row['problem_description'].'</td>
                <td>'.$row['photograph'].'</td>
                <td>'.$row['Statuszayavki'].'</td>
                </tr>';
                $counter++; // Увеличиваем значение счетчика на каждой итерации

    }

} else {
    echo "Заявки в ожидании отсутствуют.";
}
?>

  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->





    <section id="Заявкипринятыеюристом" class="facts ">
      <div class="container">

        <div class="section-title">
          <h2>Заявки принятые юристом </h2>
        </div>

        <table class="table">
  <thead>
    <tr>
        <th scope="col">№</th>
        <th scope="col">Имя клиента</th>
        <th scope="col">Данные о заявке</th>
        <th scope="col">Статус заявки</th>
        <th scope="col">Имя юриста</th>
        <th scope="col">Консультации</th>
    </tr>
  </thead>
  <tbody>
<?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests where usrName='$user_name' AND Statuszayavki='Принят' ";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
    // вывод результатов
    while ($row = mysqli_fetch_assoc($result)) {
      $consultation_status = ''; // Инициализируем переменную статуса консультации
      if ($row['Agreements']) {
          // Если значение статуса консультации уже сохранено в базе данных, сохраняем его в переменную
          $consultation_status = $row['Agreements'];
      } else {
          // Если значение статуса консультации еще не сохранено, отображаем выпадающий список
          $consultation_status = '
          <form method="post" action="save_Agreements_status.php">
              <input type="hidden" name="request_id" value="'.$row['id'].'">
              <div class="select-container">
                  <select name="consultation_status" class="consultation-select">
                      <option value="Подтвержден">Подтвердить</option>
                  </select>
              </div>
              <button type="submit" class="button-style">Сохранить</button>
          </form>';
      }
        echo '<tr>
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td><a href="fullinfouseruser.php?id=' . $row['id'] . '"  class="button-style" >Подробнее</a></td>
                <td>'.$row['Statuszayavki'].'</td>
                <td>'.$row['lawyer_name'].'</td>
                <td>'.$row['Consultations'].' <br><a href="formcoftuser.php?usrName=' .$row['usrName'].'">Данные о консультации</a> </td>
              </tr>';
            $counter++; // Увеличиваем значение счетчика на каждой итерации
    }
} else {
    echo "Принятые заявки отсутствуют.";
}
?>
  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->



    <section id="Сгенерированныйдокументотюриста" class="facts contet">
      <div class="container">
      <div class="section-title">
          <h2>Сгенерированный документ от юриста</h2>
        </div>
        <table class="table ">
  <thead>
    <tr>
        <th scope="col">№</th>
        <th scope="col">Имя клиента</th>
        <th scope="col">Данные о заявке</th>
        <th scope="col">Сгенерированный документ</th>
        <th scope="col">Формулирование согл.</th>
    </tr>
  </thead>
  <tbody>
  <?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests where usrName='$user_name'";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
    // вывод результатов
    while ($row = mysqli_fetch_assoc($result)) {
      $consultation_status = ''; // Инициализируем переменную статуса консультации
      if ($row['Agreements']) {
          // Если значение статуса консультации уже сохранено в базе данных, сохраняем его в переменную
          $consultation_status = $row['Agreements'];
      } else {
          // Если значение статуса консультации еще не сохранено, отображаем выпадающий список
          $consultation_status = '
          <form method="post" action="save_Agreements_status.php">
              <input type="hidden" name="request_id" value="'.$row['id'].'">
              <div class="select-container">
                  <select name="consultation_status" class="select-container">
                      <option value="Подтвержден">Подтвердить</option>
                      <option value="Не подтвержден">Не подтвердить</option>
                  </select>
              </div>
              <button type="submit" class="button-style">Сохранить</button>
          </form>';
      }

        echo '<tr>
            <td>'.$counter.'</td>
            <td>' . $row['usrName'] . '</td>
            <td><a href="fullinfouseruser.php?id=' . $row['id'] . '"  class="button-style" >Подробнее</a></td>
            <td><a href="' . $row['Document_generation'] . '" class="button-style"  >' . $row['Document_generation'] . '</a></td>
            <td>'.$consultation_status.'</td>
        </tr>';
        $counter++; // Увеличиваем значение счетчика на каждой итерации
    }
} else {
    echo "Сгенерированный документ от юриста отсутствуют";
}
?>
  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->



<section id="Завершенныезаявки" class="facts contet">
      <div class="container">

        <div class="section-title">
          <h2>Завершенные заявки </h2>
        </div>

        <table class="table ">
  <thead>
    <tr>
      <th scope="col">№</th>
      <th scope="col">Имя клиента</th>
      <th scope="col">Email клиента</th>
      <th scope="col">Направление</th>
      <th scope="col">Телефон</th>
      <th scope="col">Физ. лицо</th>
      <th scope="col">Юр. лицо</th>
      <th scope="col">Описание проблемы</th>
      <th scope="col">Доп. документы</th>
      <th scope="col">Статус заявки</th>
      <th scope="col">Имя юриста</th>
    </tr>
  </thead>
  <tbody>
<?php
$user_id = $_SESSION['uId']; // получаем идентификатор текущего пользователя

// SQL-запрос для выборки заявок, связанных с текущим юристом
$sql = "SELECT * FROM ConsultationRequests where usrName='$user_name' AND Statuszayavki='Завершено' ";
$result = mysqli_query($conn, $sql);

// проверка наличия результатов
if(mysqli_num_rows($result) > 0) {
  $counter = 1; // Начальное значение счетчика
    // вывод результатов
    while ($row = mysqli_fetch_assoc($result)) {
        echo '<tr>
                <td>'.$counter.'</td>
                <td>'.$row['usrName'].'</td>
                <td>'.$row['email'].'</td>
                <td>'.$row['dep'].'</td>
                <td>'.$row['phone'].'</td>
                <td>'.$row['legal_entity'].'</td>
                <td>'.$row['individual'].'</td>
                <td>'.$row['problem_description'].'</td>
                <td>'.$row['photograph'].'</td>
                <td>'.$row['Statuszayavki'].'</td>
                <td>'.$row['lawyer_name'].'</td>
            </tr>';
            $counter++; // Увеличиваем значение счетчика на каждой итерации
    }
} else {
    echo "Завершенные заявки отсутствуют.";
}
?>

  </tbody>
</table>
      
        </div>
      </div>
    </section><!-- End Facts Section -->











  
</main>
<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

<!-- Vendor JS Files -->
<script src="assets/vendor/purecounter/purecounter_vanilla.js"></script>
<script src="assets/vendor/aos/aos.js"></script>
<script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
<script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
<script src="assets/vendor/swiper/swiper-bundle.min.js"></script>
<script src="assets/vendor/typed.js/typed.min.js"></script>
<script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
<script src="assets/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="assets/js/main.js"></script>
</body>
</html>
      
<?php
}}
else{
    header("location:404 Not found.html");
}?>


   

   	




 
   
	
    
  

  <!-- loader -->
  <div id="ftco-loader" class="show fullscreen"><svg class="circular" width="48px" height="48px"><circle class="path-bg" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke="#eeeeee"/><circle class="path" cx="24" cy="24" r="22" fill="none" stroke-width="4" stroke-miterlimit="10" stroke="#F96D00"/></svg></div>


  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
    
  </body>
</html>







<style>

.table>tbody>tr:nth-child(even) {
    background-color: #f2f2f2;
}



  .select-container {
    position: relative;
    width: 100%;
}

.select-container select {
    width: 100%;
    padding: 10px;
    border: 1px solid #ccc;
    border-radius: 5px;
    background-color: #fff;
    font-size: 16px;
    appearance: none;
    -webkit-appearance: none;
    -moz-appearance: none;
    cursor: pointer;
}

.select-container::after {
    content: '\25BC'; /* символ стрелочки вниз */
    position: absolute;
    top: 50%;
    right: 10px;
    transform: translateY(-50%);
    pointer-events: none;
}

/* При фокусе */
.select-container select:focus {
    outline: none;
    border-color: #007bff;
}

/* При наведении */
.select-container select:hover {
    border-color: #007bff;
}


.buttonn {
  
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: #FF4B2B;

    
}

.buttonn:active {
	transform: scale(0.95);
}

.buttonn:focus {
	outline: none;
}

.buttonn:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
.button-style {
  margin-top: 5px;    
	border-radius: 10px;
	border: 1px solid green;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 10px 10px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
  background-color: green;
  text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}

.button-style:hover {
    background-color: green;
    border: 1px solid green;
    text-decoration: none; /* Убираем подчеркивание */
  color: #FFFFFF;
}










.container2 {
  position: relative;
  width: 11.5%;
}

.image {
  opacity: 1;
  display: block;
  width: 100%;
  height: auto;
  transition: .5s ease;
  backface-visibility: hidden;
}

.middle {
  transition: .5s ease;
  opacity: 0;
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  -ms-transform: translate(-55%, -45%);
  text-align: center;
  width:80%;
  height:80%;
}

.container2:hover .image {
  opacity: 0.3;
}

.container2:hover .middle {
  opacity: 0.7;
}

.text {
  background-color: #04AA6D;
  color: white;
  font-size: 16px;
  padding: 16px 32px;
  
}

/* Style the dropdown container */


/* Style the dropdown menu */
.consultation-select {
  width: 100%;
  padding: 10px;
  font-size: 16px;
  border: 1px solid #ccc;
  border-radius: 5px;
  background-color: #f8f8f8;
  cursor: pointer;
  outline: none;
}

/* Style the dropdown menu options */
.consultation-select option {
  padding: 10px;
}

/* Style the dropdown menu when hovered */
.consultation-select:hover {
  background-color: #e0e0e0;
}

/* Style the dropdown menu when focused */
.consultation-select:focus {
  border-color: #007bff;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
}

#hero {
  width: 100%;
  height: 49vh;
  background:  top center;
  background-size: cover;
}

#hero:before {
  content: "";
  background: 0;
  position: absolute;
  bottom: 0;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
}
</style>




