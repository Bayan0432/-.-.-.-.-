<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Заявление о признании должника банкротом(юр.лиц).docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$namesudi = $_POST['namesudi'];
$nameorg = $_POST['nameorg'];
$adressorg = $_POST['adressorg'];
$dolznic = $_POST['dolznic'];
$adressdolznic = $_POST['adressdolznic'];
$dopinfa = $_POST['dopinfa'];
$namedirector = $_POST['namedirector'];
$date = $_POST['date'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('namesudi', $namesudi);
$document->setValue('nameorg', $nameorg);
$document->setValue('adressorg', $adressorg);
$document->setValue('dolznic', $dolznic);
$document->setValue('adressdolznic', $adressdolznic);
$document->setValue('dopinfa', $dopinfa);
$document->setValue('namedirector', $namedirector);
$document->setValue('date', $date);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Заявление о признании должника банкротом(юр.лиц)' . $nameorg . '_full.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
