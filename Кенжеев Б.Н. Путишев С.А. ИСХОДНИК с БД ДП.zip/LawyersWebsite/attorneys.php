<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Наши Юристы</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.1.0/css/all.css" integrity="sha384-lKuwvrZot6UHsBSfcMvOkWwlCMgc0TaWr+30HWe3a4ltaBwTZhyTEggF5tJv8tbt" crossorigin="anonymous">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  
  </head>
  <body>
    
  <?php
session_start();
if(isset($_SESSION['uId'])) {
    $user_id = $_SESSION['uId'];
    $user_name = $_SESSION['username'];
    
    // Подключение к базе данных
    include "config.php";
    
    // Получение роли пользователя из базы данных
    $sql = "SELECT roleid FROM registration WHERE usrID = $user_id";
    $result = mysqli_query($conn, $sql);
    
    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $user_role = $row['roleid'];
    } else {
        // Если не удалось получить роль, предполагаем роль по умолчанию или обрабатываем ошибку
        $user_role = 0; // Например, роль по умолчанию - 0
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
?>
   <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
    <div class="container">
        <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="oi oi-menu"></span> Menu
        </button>

        <div class="collapse navbar-collapse" id="ftco-nav">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a href="home.php" class="nav-link">Главная</a></li>
                <li class="nav-item active"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
                <li class="nav-item"><a href="services.php" class="nav-link">Услуги</a></li>
                <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
				<li class="nav-item"><a href="logout.php" class="nav-link">Выход</a></li>
                <?php if ($user_role == 1) { ?>
                    <li class="nav-item"><a href="admin.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } elseif ($user_role == 2) { ?>
                    <li class="nav-item"><a href="lawyerPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } elseif ($user_role == 3) { ?>
                    <li class="nav-item"><a href="userPanel.php" class="nav-link">Личный кабинет - <?php echo $user_name; ?> </a></li>
                <?php } ?>
                
            </ul>
        </div>
    </div>
</nav>
      <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Лучшие юристы</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Главная <i class="ion-ios-arrow-forward"></i></a></span> <span>Наши Юристы <i class="ion-ios-arrow-forward"></i></span></p>
          </div>
          <div class="container con2">
    <br/>
	<div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8">
                            <form class="card card-sm" method="post">
                                <div class="card-body row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <i class="fas fa-search h4 text-body"></i>
                                    </div>
                                    <!--end of col-->
                                    <div class="col">
                                        <input class="form-control form-control-lg form-control-borderless" type="search" placeholder="Введите ключевое слово" name="search">
                                    </div>
                                    <!--end of col-->
                                    <div class="col-auto">
                                        <button class="btn btn-lg btn-success" type="submit" name="btn">Поиск</button>
                                    </div>
        
</form>
        </div>
       
      </div>
          <div>
       
    </section>   
         
    

    <section class="ftco-section">
    	<div class="container-fluid px-md-5">
        <div class="row">
        <?php
                include "config.php"; 
  if(isset($_POST["btn"])){
    $search=$_POST['search'];
   
$search2="SELECT * from  registration where usrName LIKE'%$search%' || Address LIKE'%$search%' || DepName LIKE'%$search%' ";
 $result2=mysqli_query($conn,$search2);
while($fetch=mysqli_fetch_array($result2)){
    echo '
        	<div class="col-lg-3 col-sm-6">
        		<div class="block-2 ftco-animate">
	            <div class="flipper">
	              <div class="front" style="background-image: url(images2/'.$fetch['lawyer_photograph'].');">
	                <div class="box">
	                  <h2>'.$fetch['usrName'].'</h2>
	                  <p>'.$fetch['DepName'].'</p>
	                </div>
	              </div>
                <div class="back">
                <blockquote>
                  <p>&ldquo; '.$fetch['usrName'].' Помогает Людям, Обеспечивая Им Справедливость, Запишитесь На Прием К
'.$fetch['usrName'].' ;</p>
                  </blockquote>
                  <div style="margin-top:60%;">
                  <a href="profiles.php?usrID='.$fetch['usrID'].'"  class="button">Перейти в профиль</a> 
                </div>
                                <div class="author d-flex">
                                
                  <div class="image align-self-center">
                    <img src="images2/'.$fetch['lawyer_photograph'].'">
                  </div>
                  <div class="name align-self-center ml-3">'.$fetch['usrName'].'<span class="position">'.$fetch['DepName'].'</span></div>
                </div>
              </div>
	              </div>
	            </div>
	          </div>
            ';
          }}
          else{
                       
          $select = mysqli_query($conn,"SELECT * FROM registration WHERE roleid =2") or die('query failed');
          while($fetch=mysqli_fetch_array($select)){    
            echo '
            <div class="col-lg-3 col-sm-6">
              <div class="block-2 ftco-animate">
                <div class="flipper flipper flip-on-hover">
                  <div class="front" style="background-image: url(images2/'.$fetch['lawyer_photograph'].');">
                    <div class="box">
                      <h2>'.$fetch['usrName'].'</h2>
                      <p>'.$fetch['DepName'].'</p>
                    </div>
                  </div>
                  <div class="back">
                  <blockquote>
                    <p>&ldquo;'.$fetch['usrName'].' Помогает Людям, Обеспечивая Им Справедливость, Запишитесь На Прием К '.$fetch['usrName'].' </p>
                    </blockquote>
                    <div style="margin-top:60%;">
                    <a href="profiles.php?usrID='.$fetch['usrID'].'"  class="button">Перейти в профиль</a> 
  </div>
                                  <div class="author d-flex">
                                  
                    <div class="image align-self-center">
                      <img src="images2/'.$fetch['lawyer_photograph'].'">
                    </div>
                    <div class="name align-self-center ml-3">'.$fetch['usrName'].'<span class="position">'.$fetch['DepName'].'</span></div>
                  </div>
                </div>
                  </div>
                </div>
              </div>
              ';
          }}
          ?>
        	</div>
</div>
</section>


 
    
<?php }
else{?>
    	  <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
          <div class="container">
            <a class="navbar-brand" href="index.php">Victory<span>Юридический центр</span></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
              <span class="oi oi-menu"></span> Menu
            </button>
  
            <div class="collapse navbar-collapse" id="ftco-nav">
              <ul class="navbar-nav ml-auto">
                <li class="nav-item"><a href="home.php" class="nav-link">Главная</a></li>
	              <li class="nav-item active"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
	              <li class="nav-item"><a href="services.php" class="nav-link">Услуги</a></li>
	              <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
	              <li class="nav-item "><a href="Register.php" class="nav-link">Регистрация </a></li>
			          <li class="nav-item "><a href="login.php" class="nav-link">Войти</a></li>
              </ul>
            </div>
            
          </div>
        </nav>
        <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Лучшие юристы</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="index.php">Главная <i class="ion-ios-arrow-forward"></i></a></span> <span>Наши Юристы<i class="ion-ios-arrow-forward"></i></span></p>
          </div>
          <div class="container">
    <br/>
	<div class="row justify-content-center">
                        <div class="col-12 col-md-10 col-lg-8">
                            <form class="card card-sm" method="post">
                                <div class="card-body row no-gutters align-items-center">
                                    <div class="col-auto">
                                        <i class="fas fa-search h4 text-body"></i>
                                    </div>
                                    <end of col-->
                                    <div class="col">
                                        <input class="form-control form-control-lg form-control-borderless" type="search" placeholder="Введите ключевое слово" name="search">
                                    </div>
                                    <!--end of col-->
                                    <div class="col-auto">
                                        <button class="btn btn-lg btn-success" type="submit" name="btn">Поиск</button>
                                    </div>
          
          
        </div>
</form>

      </div>
        </div>

      </div>
    </section>
    <section class="ftco-section">
    <div class="container-fluid px-md-5">
        <div class="row">
            <?php
            include "config.php";
            if (isset($_POST["btn"])) {
                $search = $_POST['search'];

                $search2 = "SELECT * FROM registration WHERE usrName LIKE '%$search%' || Address LIKE '%$search%' || DepName LIKE '%$search%'";
                $result2 = mysqli_query($conn, $search2);
                while ($fetch = mysqli_fetch_array($result2)) {
                    echo '
                    <div class="col-lg-3 col-sm-6">
                        <div class="block-2 ftco-animate">
                            <div class="flipper flip-on-hover">
                                <div class="front" style="background-image: url(images2/' . $fetch['lawyer_photograph'] . ');">
                                    <div class="box">
                                        <h2>' . $fetch['usrName'] . '</h2>
                                        <p>' . $fetch['DepName'] . '</p>
                                    </div>
                                </div>
                                <div class="back">
                                    <blockquote>
                                        <p>&ldquo; ' . $fetch['usrName'] . ' Помогает Людям, Обеспечивая Им Справедливость, Запишитесь На Прием К ' . $fetch['usrName'] . ' </p>
                                    </blockquote>
                                    <p style="margin-top:30%;"><b>Сначала Войдите в Систему, Чтобы Просмотреть Профиль</b></p>
                                    <div class="author d-flex">
                                        <div class="image align-self-center">
                                            <img src="images2/' . $fetch['lawyer_photograph'] . '">
                                        </div>
                                        <div class="name align-self-center ml-3">' . $fetch['usrName'] . '<span class="position">' . $fetch['DepName'] . '</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ';
                }
            } else {
                $select = mysqli_query($conn, "SELECT * FROM registration WHERE roleid =2") or die('query failed');
                while ($fetch = mysqli_fetch_array($select)) {
                    echo '
                    <div class="col-lg-3 col-sm-6">
                        <div class="block-2 ftco-animate">
                            <div class="flipper flip-on-hover">
                                <div class="front" style="background-image: url(images2/' . $fetch['lawyer_photograph'] . ');">
                                    <div class="box">
                                        <h2>' . $fetch['usrName'] . '</h2>
                                        <p>' . $fetch['DepName'] . '</p>
                                    </div>
                                </div>
                                <div class="back">
                                    <blockquote>
                                        <p>&ldquo; ' . $fetch['usrName'] . ' Помогает Людям, Обеспечивая Им Справедливость, Запишитесь На Прием К ' . $fetch['usrName'] . ' </p>
                                    </blockquote>
                                    <p style="margin-top:30%;"><b>Сначала Войдите в Систему, Чтобы Просмотреть Профиль</b></p>
                                    <div class="author d-flex">
                                        <div class="image align-self-center">
                                            <img src="images2/' . $fetch['lawyer_photograph'] . '">
                                        </div>
                                        <div class="name align-self-center ml-3">' . $fetch['usrName'] . '<span class="position">' . $fetch['DepName'] . '</span></div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    ';
                }
            }
            ?>
        </div>
    </div>
</section>




<?php 
}?>
<?php include 'footer.php'  ?>

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>

  <script >$(document).ready(function() {
    $('.card-link').click(function(event) {
        event.preventDefault(); // Отменяем стандартное действие ссылки
        $(this).closest('.flipper').toggleClass('flipped');
    });
});</script>


  <style>
    .form-control-borderless {
    border: none;
}

.form-control-borderless:hover, .form-control-borderless:active, .form-control-borderless:focus {
    border: none;
    outline: none;
    box-shadow: none;
}


    .button {
      margin-top:80%;
  margin-left:18%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	background-color: #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
}

.button:active {
	transform: scale(0.95);
  text-decoration:none;
}

.button:focus {
	outline: none;

}

.button.ghost {
	background-color: transparent;
	border-color: #FFFFFF;
}
  .button:hover{
    background-color:#93734C;

  }

/* Добавьте этот CSS в ваш файл стилей */
.flipper-container {
    perspective: 1000px; /* Задает перспективу для 3D-пространства */
}

.flipper {

    position: relative;
    transform-style: preserve-3d;
    transition: transform 1.5s;
}

.flipper:hover {
    transform: rotateY(180deg);
}

.front, .back {
    width: 100%;
    height: 100%;
    position: absolute;
    backface-visibility: hidden; /* Скрытие обратной стороны при вращении */
}

.back {
    transform: rotateY(180deg);
}



</style>
    
  </body>;
</html>
