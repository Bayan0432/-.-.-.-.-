<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Запрос для юридического лица к микрофинансовой организации (МФО).docx');

// Обработка данных из формы
$namecomp = $_POST['namecomp'];
$uradress = $_POST['uradress'];
$contdannie = $_POST['contdannie'];
$date = $_POST['date'];
$namemfo = $_POST['namemfo'];
$adressmfo = $_POST['adressmfo'];
$contactmfo = $_POST['contactmfo'];

$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namecomp', $namecomp);
$document->setValue('uradress', $uradress);
$document->setValue('contdannie', $contdannie);
$document->setValue('date', $date);
$document->setValue('namemfo', $namemfo);
$document->setValue('adressmfo', $adressmfo);
$document->setValue('contactmfo', $contactmfo);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Запрос для юридического лица к микрофинансовой организации (МФО)' . $namecomp . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
