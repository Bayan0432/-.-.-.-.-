<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета с физического лица (по решению суда).docx');

// Обработка данных из формы
$namebank = $_POST['namebank'];
$adressbank = $_POST['adressbank'];
$date = $_POST['date'];
$numchet = $_POST['numchet'];
$rechenie = $_POST['rechenie'];
$prichina = $_POST['prichina'];
$name = $_POST['name'];
$daterojd = $_POST['daterojd'];
$daressreg = $_POST['daressreg'];
$numpassport = $_POST['numpassport'];
$numtel = $_POST['numtel'];
$doc = $_POST['doc'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namebank', $namebank);
$document->setValue('adressbank', $adressbank);
$document->setValue('date', $date);
$document->setValue('numchet', $numchet);
$document->setValue('rechenie', $rechenie);
$document->setValue('prichina', $prichina);
$document->setValue('name', $name);
$document->setValue('daterojd', $daterojd);
$document->setValue('daressreg', $daressreg);
$document->setValue('numpassport', $numpassport);
$document->setValue('numtel', $numtel);
$document->setValue('doc', $doc);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета с физического лица (по решению суда)' . $namebank . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
