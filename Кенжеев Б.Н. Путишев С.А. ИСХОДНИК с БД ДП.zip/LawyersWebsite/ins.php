<!DOCTYPE html>
<html lang="en">
  <head>
    <title>Legalcare - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    <!DOCTYPE html>
<html lang="en">
  <head>
    <title>Legalcare - Free Bootstrap 4 Template by Colorlib</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    
    <link href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700,800,900" rel="stylesheet">

    <link rel="stylesheet" href="css/open-iconic-bootstrap.min.css">
    <link rel="stylesheet" href="css/animate.css">
    
    <link rel="stylesheet" href="css/owl.carousel.min.css">
    <link rel="stylesheet" href="css/owl.theme.default.min.css">
    <link rel="stylesheet" href="css/magnific-popup.css">

    <link rel="stylesheet" href="css/aos.css">

    <link rel="stylesheet" href="css/ionicons.min.css">
    
    <link rel="stylesheet" href="css/flaticon.css">
    <link rel="stylesheet" href="css/icomoon.css">
    <link rel="stylesheet" href="css/style.css">
  </head>

  <body>
  <?php
session_start();
if(isset($_SESSION['uId'])) {
		$user_id = $_SESSION['uId'];
		$user_name = $_SESSION['username'];
	?>
   
   <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Меню
	      </button>

	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="home.php" class="nav-link">Главная</a></li>
	          <li class="nav-item"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
	          <li class="nav-item active"><a href="services.php" class="nav-link">Услуги</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
	          <li class="nav-item "><a href="logout.php" class="nav-link">Выход</a></li>
			      <li class="nav-item "><a href="userPanel.php" class="nav-link"> Личный кабинет -  <?php echo $user_name; ?> </a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>

      <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Снятие запрета на выезд</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Главная <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="services.php">Услуги<i class="ion-ios-arrow-forward"></i></a></span> <span>Снятие запрета на выезд<i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
   	
   	<section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 ftco-animate">
          	<p>
              <img src="images/Снятие запрета на выезд.jpg" alt="" class="img-fluid">
            </p>
            <h2 class="mb-3">Что такое Снятие запрета на выезд?</h2>
<p>Снятие запрета на выезд — это процедура, касающаяся граждан, которым был наложен запрет на выезд за пределы страны по различным причинам, таким как судебные решения, задолженности перед государством или другие юридические обязательства. Это правовая процедура, которая обычно требует определенных юридических шагов и формальностей.</p>
<p>В контексте законодательства каждой страны или региона снятие запрета на выезд может регулироваться различными законами и положениями. Обычно для этого требуется обращение в компетентные государственные органы, предоставление необходимых документов и выполнение определенных условий.</p>
<p>Юристы, специализирующиеся на иммиграционном праве или праве гражданства, хорошо знакомы с процессом снятия запрета на выезд и могут оказать необходимую помощь в этом вопросе, обеспечивая соблюдение всех юридических требований и процедурных норм. Они могут консультировать клиентов, представлять их интересы перед государственными органами и обеспечивать соблюдение их прав в рамках данной процедуры.</p>
            <h2 class="mb-3 mt-5">Как мы можем помочь !</h2>
            <p>Если вам необходима помощь в процессе снятия запрета на выезд, наши квалифицированные адвокаты готовы оказать вам поддержку и решить все ваши вопросы. Независимо от сложности вашей ситуации, мы обеспечим вам профессиональное юридическое сопровождение, чтобы помочь вам достичь желаемого результата. Обращайтесь к нам, и мы окажем вам необходимую помощь в этом важном юридическом вопросе.</p>
            <div class="row mt-5 pt-5">
		          <div class="col-md-12">
		            <h2 class="mb-4 font-weight-bold">Наши Юристы</h2>
		          </div>
                  <?php
    include "config.php";
          $select = mysqli_query($conn,"SELECT * FROM registration WHERE roleid =2 AND DepName='Снятие запрета на выезд'") or die('query failed');
while($fetch=mysqli_fetch_array($select)){           
    echo '
    <div class="col-lg-3 col-sm-6">
    <div class="block-2 ftco-animate">
      <div class="flipper">
        <div class="front" style="background-image: url(images2/'.$fetch['lawyer_photograph'].');">
          <div class="box">
            <h2>'.$fetch['usrName'].'</h2>
            <p>'.$fetch['DepName'].'</p>
          </div>
        </div>
        <div class="back">
        <blockquote>
          <p>&ldquo; '.$fetch['usrName'].' Один из наших лучших адвокатов. '.$fetch['usrName'].' Помогает людям, обеспечивая им справедливость. Запишитесь на прием к '.$fetch['usrName'].'  &rdquo;</p>
          </blockquote>
          <div style="margin-top:80%;">
          <a href="profiles.php?usrID='.$fetch['usrID'].'"  class="button">Перейти в профиль</a> 
</div>
                      <div class="author d-flex">
                        
          <div class="image align-self-center">
            <img src="images2/'.$fetch['lawyer_photograph'].'">
          </div>
          <div class="name align-self-center ml-3">'.$fetch['usrName'].'<span class="position">'.$fetch['DepName'].'</span></div>
        </div>
      </div>
        </div>
      </div>
    </div>
            ';
}?>
            </div>
<?php } else{?>
	  <nav class="navbar px-md-0 navbar-expand-lg navbar-dark ftco_navbar bg-dark ftco-navbar-light" id="ftco-navbar">
	    <div class="container">
	      <a class="navbar-brand" href="index.php">Victory <span>юридический центр</span></a>
	      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#ftco-nav" aria-controls="ftco-nav" aria-expanded="false" aria-label="Toggle navigation">
	        <span class="oi oi-menu"></span> Меню
	      </button>
	      <div class="collapse navbar-collapse" id="ftco-nav">
	        <ul class="navbar-nav ml-auto">
            <li class="nav-item"><a href="home.php" class="nav-link">Главная</a></li>
	          <li class="nav-item"><a href="attorneys.php" class="nav-link">Наши Юристы</a></li>
	          <li class="nav-item active"><a href="services.php" class="nav-link">Услуги</a></li>
	          <li class="nav-item"><a href="contact.php" class="nav-link">Контакты</a></li>
	          <li class="nav-item "><a href="Register.php" class="nav-link">Регистрация </a></li>
			      <li class="nav-item "><a href="login.php" class="nav-link">Войти</a></li>
	        </ul>
	      </div>
	    </div>
	  </nav>
    <!-- END nav -->
    <section class="hero-wrap hero-wrap-2" style="background-image: url('images/bg_1.jpg');" data-stellar-background-ratio="0.5">
      <div class="overlay"></div>
      <div class="container">
        <div class="row no-gutters slider-text align-items-end justify-content-center">
          <div class="col-md-9 ftco-animate pb-5 text-center">
            <h1 class="mb-3 bread">Снятие запрета на выезд</h1>
            <p class="breadcrumbs"><span class="mr-2"><a href="home.php">Главная <i class="ion-ios-arrow-forward"></i></a></span> <span class="mr-2"><a href="services.php">Услуги<i class="ion-ios-arrow-forward"></i></a></span> <span>Снятие запрета на выезд<i class="ion-ios-arrow-forward"></i></span></p>
          </div>
        </div>
      </div>
    </section>
   	
   	<section class="ftco-section ftco-degree-bg">
      <div class="container">
        <div class="row">
          <div class="col-lg-8 ftco-animate">
          <p>
              <img src="images/Снятие запрета на выезд.jpg" alt="" class="img-fluid">
            </p>
            <h2 class="mb-3">Что такое Снятие запрета на выезд?</h2>
<p>Снятие запрета на выезд — это процедура, касающаяся граждан, которым был наложен запрет на выезд за пределы страны по различным причинам, таким как судебные решения, задолженности перед государством или другие юридические обязательства. Это правовая процедура, которая обычно требует определенных юридических шагов и формальностей.</p>
<p>В контексте законодательства каждой страны или региона снятие запрета на выезд может регулироваться различными законами и положениями. Обычно для этого требуется обращение в компетентные государственные органы, предоставление необходимых документов и выполнение определенных условий.</p>
<p>Юристы, специализирующиеся на иммиграционном праве или праве гражданства, хорошо знакомы с процессом снятия запрета на выезд и могут оказать необходимую помощь в этом вопросе, обеспечивая соблюдение всех юридических требований и процедурных норм. Они могут консультировать клиентов, представлять их интересы перед государственными органами и обеспечивать соблюдение их прав в рамках данной процедуры.</p>
            <h2 class="mb-3 mt-5">Как мы можем помочь !</h2>
            <p>Если вам необходима помощь в процессе снятия запрета на выезд, наши квалифицированные адвокаты готовы оказать вам поддержку и решить все ваши вопросы. Независимо от сложности вашей ситуации, мы обеспечим вам профессиональное юридическое сопровождение, чтобы помочь вам достичь желаемого результата. Обращайтесь к нам, и мы окажем вам необходимую помощь в этом важном юридическом вопросе.</p>
            <div class="row mt-5 pt-5">
		          <div class="col-md-12">
		            <h2 class="mb-4 font-weight-bold">Наши Юристы</h2>
		          </div>
                  <?php
    include "config.php";
          $select = mysqli_query($conn,"SELECT * FROM registration WHERE roleid =2 AND DepName='Снятие запрета на выезд'") or die('query failed');
while($fetch=mysqli_fetch_array($select)){           
    echo '
    <div class="col-lg-3 col-sm-6">
    <div class="block-2 ftco-animate">
        <div class="flipper flip-on-hover">
            <div class="front" style="background-image: url(images2/' . $fetch['lawyer_photograph'] . ');">
                <div class="box">
                    <h2>' . $fetch['usrName'] . '</h2>
                    <p>' . $fetch['DepName'] . '</p>
                </div>
            </div>
            <div class="back">
                <blockquote>
                    <p>&ldquo; ' . $fetch['usrName'] . ' Один из наших лучших адвокатов. ' . $fetch['usrName'] . 'Помогает людям, обеспечивая им справедливость;</p>
                </blockquote>
                <p style="margin-top:60%;"><b>Сначала Войдите в Систему, Чтобы Просмотреть Профиль</b></p>
                <div class="author d-flex">
                    <div class="image align-self-center">
                        <img src="images2/' . $fetch['lawyer_photograph'] . '">
                    </div>
                    <div class="name align-self-center ml-3">' . $fetch['usrName'] . '<span class="position">' . $fetch['DepName'] . '</span></div>
                </div>
            </div>
        </div>
    </div>
</div>';
}?>
            </div>
    <?php }?>
   
						


          </div> <!-- .col-md-8 -->
          <div class="col-lg-4 sidebar pl-lg-5 ftco-animate">
           
            <div class="sidebar-box ftco-animate">
              <div class="categories">
                <h3>Услуги</h3>
                <li ><a href="bus.php">Банкротство<span class="ion-ios-arrow-forward"></span></a></li>
                <li><a href="crim.php">Снятие ареста со счетов <span class="ion-ios-arrow-forward"></span></a></li>
                <li class="active"><a href="ins.php">Снятие запрета на выезд <span class="ion-ios-arrow-forward"></span></a></li>
                <li><a href="emp.php">График МФО <span class="ion-ios-arrow-forward"></span></a></li>
              </div>
            </div>

           
        </div>
      </div>
    </section> <!-- .section -->

   
    <?php include 'footer.php'  ?>
  

  <script src="js/jquery.min.js"></script>
  <script src="js/jquery-migrate-3.0.1.min.js"></script>
  <script src="js/popper.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
  <script src="js/jquery.easing.1.3.js"></script>
  <script src="js/jquery.waypoints.min.js"></script>
  <script src="js/jquery.stellar.min.js"></script>
  <script src="js/owl.carousel.min.js"></script>
  <script src="js/jquery.magnific-popup.min.js"></script>
  <script src="js/aos.js"></script>
  <script src="js/jquery.animateNumber.min.js"></script>
  <script src="js/scrollax.min.js"></script>
  <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyBVWaKrjvy3MaE7SQ74_uJiULgl1JY0H2s&sensor=false"></script>
  <script src="js/google-map.js"></script>
  <script src="js/main.js"></script>
  <script >$(document).ready(function() {
    $('.card-link').click(function(event) {
        event.preventDefault(); // Отменяем стандартное действие ссылки
        $(this).closest('.flipper').toggleClass('flipped');
    });
});</script>
  </body>
</html>
<style>
.block-2, .block-2 .front, .block-2 .back {
    width: 140%;
    height: 400px;
}


        .button {
      margin-top:80%;
  margin-left:18%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	background-color: #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
}

.button:active {
	transform: scale(0.95);
  text-decoration:none;
}

.button:focus {
	outline: none;

}

.button.ghost {
	background-color: transparent;
	border-color: #FFFFFF;
}
  .button:hover{
    background-color:#93734C;

  }

/* Добавьте этот CSS в ваш файл стилей */
.flipper-container {
    perspective: 1000px; /* Задает перспективу для 3D-пространства */
}

.flipper {

    position: relative;
    transform-style: preserve-3d;
    transition: transform 1.5s;
}

.flipper:hover {
    transform: rotateY(180deg);
}

.front, .back {
    width: 100%;
    height: 100%;
    position: absolute;
    backface-visibility: hidden; /* Скрытие обратной стороны при вращении */
}

.back {
    transform: rotateY(180deg);
}
.sidebar-box {
    position: -webkit-sticky; /* Для поддержки веб-кит браузеров */
    position: sticky;
    top: 100px; /* Регулируйте значение top по вашему усмотрению */
}
</style>