<?php
include "config.php";

if(isset($_POST['request_id']) && isset($_POST['lawyer_name'])){
    $request_id = $_POST['request_id'];
    $lawyer_name = $_POST['lawyer_name'];

    // Получение идентификатора юриста по его имени
    $sql_lawyer_id = "SELECT file_link FROM generated_files WHERE lawyer_name = '$lawyer_name'";
    $result_lawyer_id = mysqli_query($conn, $sql_lawyer_id);
    if($result_lawyer_id){
        $row_lawyer_id = mysqli_fetch_assoc($result_lawyer_id);
        $lawyer_id = $row_lawyer_id['usrID'];

        // SQL запрос для обновления записи о заявке с указанием юриста
        $sql_update = "UPDATE ConsultationRequests SET Document_generation = '$lawyer_name' WHERE id = $request_id";
        
        // Выполнение запроса на обновление записи
        if(mysqli_query($conn, $sql_update)){
            echo '<script>alert("Сгенерированный документ успешно добавлен в заявку."); window.location.href = "lawyerPanel.php";</script>';
        } else{
            echo "ERROR: Не удалось выполнить запрос. " . mysqli_error($conn);
        }
    } else {
        echo "ERROR: Не удалось выполнить запрос для получения идентификатора юриста. " . mysqli_error($conn);
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
}
?>
