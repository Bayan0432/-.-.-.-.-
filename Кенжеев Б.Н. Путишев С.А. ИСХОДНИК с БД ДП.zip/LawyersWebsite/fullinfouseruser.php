<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Подробная информация о заявке</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
        }
        .container {
            
            max-width: 800px;
            margin: 0 auto;
            margin-bottom:50px;
            background-color: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #333;
        }
        p {
            color: #666;
            margin-bottom: 10px;
        }
        .button-style {
            background-color: #007bff;
            color: #fff;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            text-decoration: none;
            transition: background-color 0.3s ease;
        }
        .button-style:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <div class="container">
        <?php
        include "config.php";

        if(isset($_GET['id'])) {
            $request_id = $_GET['id'];
            $sql = "SELECT * FROM ConsultationRequests WHERE id = '$request_id'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                echo "<h2>Подробная информация о заявке</h2>";
                echo "<p><strong>Имя клиента:</strong> " . $row['usrName'] . "</p>";
                echo "<p><strong>Email клиента:</strong> " . $row['email'] . "</p>";
                echo "<p><strong>Направление:</strong> " . $row['dep'] . "</p>";
                echo "<p><strong>Телефон:</strong> " . $row['phone'] . "</p>";
                echo "<p><strong>Физ. лицо:</strong> " . $row['legal_entity'] . "</p>";
                echo "<p><strong>Юр. лицо:</strong> " . $row['individual'] . "</p>";
                echo "<p><strong>Описание проблемы:</strong> " . $row['problem_description'] . "</p>";
                echo "<p><strong>Доп. документы:</strong> <a href='". $row['photograph'] . "' class='button-style'>". $row['photograph'] ."</a></p>";

            } else {
                echo "Заявка не найдена.";
            }
        } else {
            echo "Идентификатор заявки не указан.";
        }

        mysqli_close($conn);
        ?>
        
    </div>
    <a href="userPanel.php"  class="button">Вернуться в кабинет</a>
</body>
</html>
<style>
    .button {
    margin-left:35%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;
    margin-top: 10px;
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
</style>
