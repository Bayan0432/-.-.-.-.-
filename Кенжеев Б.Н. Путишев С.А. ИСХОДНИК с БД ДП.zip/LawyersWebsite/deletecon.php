<?php
include "config.php";
$id = $_GET['id'];
$sql = "DELETE from contact where id = '$id'";
$result=mysqli_query($conn,$sql);
header("location:admin.php");
?>
