<?php

include "config.php";
$id = $_GET['usrID'];
$sql = "DELETE from registration where usrID = '$id'";
$result=mysqli_query($conn,$sql);
header("location:admin.php");
?>
