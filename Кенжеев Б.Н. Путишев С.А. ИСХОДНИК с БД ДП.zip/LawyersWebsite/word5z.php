<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета с физического лица (по истечении срока).docx');

// Обработка данных из формы
$namebank = $_POST['namebank'];
$adresbank = $_POST['adresbank'];
$date = $_POST['date'];
$numchet = $_POST['numchet'];
$name = $_POST['name'];
$daterojd = $_POST['daterojd'];
$adressreg = $_POST['adressreg'];
$numpassport = $_POST['numpassport'];
$num = $_POST['num'];
$doc = $_POST['doc'];
$namelic = $_POST['namelic'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namebank', $namebank);
$document->setValue('adresbank', $adresbank);
$document->setValue('date', $date);
$document->setValue('numchet', $numchet);
$document->setValue('name', $name);
$document->setValue('daterojd', $daterojd);
$document->setValue('adressreg', $adressreg);
$document->setValue('numpassport', $numpassport);
$document->setValue('num', $num);
$document->setValue('doc', $doc);
$document->setValue('namelic', $namelic);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета с физического лица (по истечении срока)' . $namebank . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
