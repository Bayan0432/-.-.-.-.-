<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета на выезд для несовершенного.docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$adresssud = $_POST['adresssud'];
$date = $_POST['date'];
$namepapa = $_POST['namepapa'];
$namemama = $_POST['namemama'];
$namereb = $_POST['namereb'];
$daterojd = $_POST['daterojd'];
$mestrojd = $_POST['mestrojd'];
$adressreg = $_POST['adressreg'];
$iin = $_POST['iin'];
$pasportdan = $_POST['pasportdan'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('adresssud', $adresssud);
$document->setValue('date', $date);
$document->setValue('namepapa', $namepapa);
$document->setValue('namemama', $namemama);
$document->setValue('namereb', $namereb);
$document->setValue('daterojd', $daterojd);
$document->setValue('mestrojd', $mestrojd);
$document->setValue('adressreg', $adressreg);
$document->setValue('iin', $iin);
$document->setValue('pasportdan', $pasportdan);

// Сохраняем прикрепленные файлы
$targetDir = "uploads/";
$uploadedFiles = [];
foreach ($_FILES['files']['name'] as $key => $name) {
    $targetFilePath = $targetDir . basename($_FILES['files']['name'][$key]);
    if (move_uploaded_file($_FILES['files']['tmp_name'][$key], $targetFilePath)) {
        $uploadedFiles[] = $targetFilePath;
    }
}

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета на выезд для несовершенного' . $namereb . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
