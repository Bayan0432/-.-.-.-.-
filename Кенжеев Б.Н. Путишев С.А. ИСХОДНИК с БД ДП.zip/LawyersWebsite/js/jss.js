function validateForm() {
    var name = document.getElementById('name').value;
    var email = document.getElementById('email').value;
    var dep = document.getElementById('dep').value;
    var lawyer = document.getElementById('lawyer_name').value;

    // Проверка обязательных полей
    if (name.trim() === '' || email.trim() === '' || dep === '' || lawyer === '') {
        alert('Пожалуйста, заполните все обязательные поля.');
        return false;
    }
    return true;
}