<?php

include "config.php";
$id = $_GET['id'];
$sql = "UPDATE ConsultationRequests set Statuszayavki='Завершено' where id = '$id'";
$result=mysqli_query($conn,$sql);
header("location:lawyerPanel.php");
?>