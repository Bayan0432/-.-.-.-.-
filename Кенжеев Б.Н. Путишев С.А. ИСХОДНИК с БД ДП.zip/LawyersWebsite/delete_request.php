<?php
include "config.php";

if(isset($_GET['id'])){
    $id = $_GET['id'];

    // SQL запрос для удаления записи из базы данных
    $sql = "DELETE FROM ConsultationRequests WHERE id = $id";
    
    // Выполнение запроса
    if(mysqli_query($conn, $sql)){
        echo '<script>alert("Заявка успешно удалена."); window.location.href = "admin.php";</script>';
    } else{
        echo "ERROR: Не удалось выполнить запрос. " . mysqli_error($conn);
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
} else {
    echo "Ошибка: Не передан идентификатор заявки.";
}
?>