<?php
include "config.php";
$id = $_GET['id'];
$sql = "DELETE from appointments where id = '$id'";
$result=mysqli_query($conn,$sql);
header("location:appointment.php");
?>
