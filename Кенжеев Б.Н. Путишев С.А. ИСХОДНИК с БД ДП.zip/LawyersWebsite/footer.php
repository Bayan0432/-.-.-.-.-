<footer class="ftco-footer ftco-bg-dark ftco-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
              <h2 class="logo"><a href="index.php">Victory <span>Юридический центр</span></a></h2>
              <p>Мы помогли сотням людей решить юридические проблемы. Теперь они доверяют юристам Victory</p>
              <ul class="ftco-footer-social list-unstyled float-md-left float-lft mt-5">
                <li class="ftco-animate"><a href="#"><span class="icon-twitter"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-facebook"></span></a></li>
                <li class="ftco-animate"><a href="#"><span class="icon-instagram"></span></a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4 ml-md-5">
              <h2 class="ftco-heading-2">Наши услуги</h2>
              <ul class="list-unstyled">
                <li><a href="bus.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Банкротство</a></li>
                <li><a href="crim.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Снятие ареста со счетов</a></li>
                <li><a href="ins.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>Снятие запрета на выезд</a></li>
                <li><a href="emp.php" class="py-1 d-block"><span class="ion-ios-arrow-forward mr-3"></span>График МФО</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md">
            <div class="ftco-footer-widget mb-4">
            	<h2 class="ftco-heading-2">Есть вопросы ?</h2>
            	<div class="block-23 mb-3">
	              <ul>
	                <li><span class="icon icon-map-marker"></span><span class="text">Петропавловск, Ул. Имени Евнея Букетова, Д. 53, Кв. 31. </span></li>
	                <li><a href="#"><span class="icon icon-phone"></span><span class="text">+7 705 123 65 34</span></a></li>
	                <li><a href="#"><span class="icon icon-envelope"></span><span class="text">Victory@gmail.com</span></a></li>
	              </ul>
	            </div>
            </div>
          </div>
          <div class="col-md">
             <div class="ftco-footer-widget mb-4">
              <h2 class="ftco-heading-2">Рабочее время</h2>
              <div class="opening-hours">
              	<h4>Рабочее время:</h4>
              	<p class="pl-3">
              		<span>Понедельник – Пятница : с 9:00 до 20:00 часов</span>
              		<span>Суббота : c 9:00 до 20:00 часов</span>
              	</p>
              	<h4>Выходные:</h4>
              	<p class="pl-3">
              		<span>Воскресенье выходной</span>
              		<span>официальный</span>
              	</p>
              </div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-md-12 text-center">

<p>  Victory &copy;<script>document.write(new Date().getFullYear());</script> Все права защищены</p> 
          </div>
        </div>
      </div>
    </footer>