<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета с юридического лица (по решению суда).docx');

// Обработка данных из формы
$namebank = $_POST['namebank'];
$adressbank = $_POST['adressbank'];
$date = $_POST['date'];
$numchet = $_POST['numchet'];
$reshen = $_POST['reshen'];
$prichina = $_POST['prichina'];
$nameurlic = $_POST['nameurlic'];
$uradress = $_POST['uradress'];
$inn = $_POST['inn'];
$ogrn = $_POST['ogrn'];
$numtel = $_POST['numtel'];
$doc = $_POST['doc'];
$namelic = $_POST['namelic'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namebank', $namebank);
$document->setValue('adressbank', $adressbank);
$document->setValue('date', $date);
$document->setValue('numchet', $numchet);
$document->setValue('reshen', $reshen);
$document->setValue('prichina', $prichina);
$document->setValue('nameurlic', $nameurlic);
$document->setValue('uradress', $uradress);
$document->setValue('inn', $inn);
$document->setValue('ogrn', $ogrn);
$document->setValue('numtel', $numtel);
$document->setValue('doc', $doc);
$document->setValue('namelic', $namelic);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета с юридического лица (по решению суда)' . $nameurlic . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
