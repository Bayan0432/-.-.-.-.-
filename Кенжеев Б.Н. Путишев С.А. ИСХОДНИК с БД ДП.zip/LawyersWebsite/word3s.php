<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие временного запрета на выезд для физических лиц (по причинам).docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$adresssud = $_POST['adresssud'];
$date = $_POST['date'];
$prichina = $_POST['prichina'];
$name = $_POST['name'];
$daterojd = $_POST['daterojd'];
$mestorojd = $_POST['mestorojd'];
$adressreg = $_POST['adressreg'];
$iin = $_POST['iin'];
$passportdan = $_POST['passportdan'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('adresssud', $adresssud);
$document->setValue('date', $date);
$document->setValue('prichina', $prichina);
$document->setValue('name', $name);
$document->setValue('daterojd', $daterojd);
$document->setValue('mestorojd', $mestorojd);
$document->setValue('adressreg', $adressreg);
$document->setValue('iin', $iin);
$document->setValue('passportdan', $passportdan);

// Сохраняем прикрепленные файлы
$targetDir = "uploads/";
$uploadedFiles = [];
foreach ($_FILES['files']['name'] as $key => $name) {
    $targetFilePath = $targetDir . basename($_FILES['files']['name'][$key]);
    if (move_uploaded_file($_FILES['files']['tmp_name'][$key], $targetFilePath)) {
        $uploadedFiles[] = $targetFilePath;
    }
}

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие временного запрета на выезд для физических лиц (по причинам)' . $name . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
