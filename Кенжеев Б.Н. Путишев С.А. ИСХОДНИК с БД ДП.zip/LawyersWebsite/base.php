<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LawyerDetails</title>
    
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
<link href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.3.0/css/font-awesome.css" 
  rel="stylesheet"  type='text/css'>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@3.3.7/dist/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
<script>
        function checkLegalEntity() {
            if (document.getElementById('legal_entity').checked) {
                document.getElementById('individual').disabled = true;
            } else {
                document.getElementById('individual').disabled = false;
            }
        }

        function checkIndividual() {
            if (document.getElementById('individual').checked) {
                document.getElementById('legal_entity').disabled = true;
            } else {
                document.getElementById('legal_entity').disabled = false;
            }
        }
</script>
<script>
document.addEventListener('DOMContentLoaded', function() {
    var form = document.getElementById('contact_form');
    form.addEventListener('submit', function(event) {
        var name = form.querySelector('[name="name"]').value;
        var email = form.querySelector('[name="email"]').value;
        var dep = form.querySelector('[name="dep"]').value;
        var legal_entity = form.querySelector('[name="legal_entity"]').checked;
        var individual = form.querySelector('[name="individual"]').checked;
        var phone = form.querySelector('[name="phone"]').value;
        var problem_description = form.querySelector('[name="problem_description"]').value;

        if (!name || !email || !dep || (!legal_entity && !individual) || !phone || !problem_description ) {
            event.preventDefault(); // Предотвращаем отправку формы
            alert('Пожалуйста, заполните обязательные поля: Имя, Email, Направление ,Опишите вашу проблему , Номер телефона и выберите Юридическое или Физическое лицо.');
        }
    });
});
</script>




</head>
<body>
<?php
session_start();
if(isset($_SESSION['uId'])) 
		$user_id = $_SESSION['uId'];
		$user_name = $_SESSION['username'];
?>





<?php
include "config.php"; // Подключение к базе данных

if(isset($_POST['lawSubmit'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $dep = $_POST['dep'];
    $legal_entity = isset($_POST['legal_entity']) ? 1 : 0;
    $individual = isset($_POST['individual']) ? 1 : 0;
    $phone = $_POST['phone'];
    $problem_description = $_POST['problem_description'];
    $photograph = $_FILES['lawyer_photograph']['name']; // Имя загружаемого файла
    $Statuszayavki = $_POST['Pending'];
    $lawyer = $_POST['lawyer_name'];
    $lawyer_id = $_POST['lawyer_id'];


    // Получение идентификатора юриста по его имени
    $sql_lawyer_id = "SELECT usrID FROM registration WHERE usrName = '$lawyer' AND roleid = 2";
    $result_lawyer_id = mysqli_query($conn, $sql_lawyer_id);
    $lawyer_id = 0; // Инициализация переменной
    if($result_lawyer_id && mysqli_num_rows($result_lawyer_id) > 0){
        $row_lawyer_id = mysqli_fetch_assoc($result_lawyer_id);
        $lawyer_id = $row_lawyer_id['usrID'];
    }



    // Путь для сохранения загружаемого файла
    $target = "uploads/" . basename($photograph);

    // Загрузка файла на сервер
    move_uploaded_file($_FILES['lawyer_photograph']['tmp_name'], $target);

    // SQL-запрос для вставки данных в таблицу
    $sql = "INSERT INTO ConsultationRequests (usrName, email, dep, legal_entity, individual, phone, problem_description, photograph ,lawyer_name, lawyer_id , Statuszayavki) 
            VALUES ('$name', '$email', '$dep', '$legal_entity', '$individual', '$phone', '$problem_description', '$target' ,'$lawyer'  , '$lawyer_id' ,'в ожидании')";

    // Выполнение SQL-запроса
    if(mysqli_query($conn, $sql)){
        echo '<script>alert("Данные успешно добавлены в базу данных."); window.location.href = "home.php";</script>';
    } else{
        echo "ERROR: Не удалось выполнить запрос. " . mysqli_error($conn);
    }
    
    // Закрытие соединения с базой данных
    mysqli_close($conn);
}
?>



    <div class="container">
        <form class="well form-horizontal" method="post" id="contact_form" enctype="multipart/form-data" novalidate="novalidate" onsubmit="return validateForm()">
            <fieldset>
                <!-- Form Name -->
                <legend><center><h2><b>Добро пожаловать на форму подачи заявки</b></h2></center></legend><br>
                <div class="form-group">
                    <label class="col-md-4 control-label">Имя <span style="color: red;">*</span></label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input name="name" placeholder="Введите ФИО" class="form-control" type="text" required value="<?php echo $user_name; ?>">
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label">Email <span style="color: red;">*</span></label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                            <input name="email" placeholder="Введите вашу почту" class="form-control" type="email" required>
                        </div>
                    </div>
                </div>
                <div class="form-group"> 
                    <label class="col-md-4 control-label">Ваше направление <span style="color: red;">*</span></label>
                    <div class="col-md-4 selectContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                            <select name="dep"  class="form-control">
                                <option  selected value="">Выберите ваше направление </option>
                                <?php 
                                include "config.php";
                                $sql="Select * From departments";
                                $result=mysqli_query($conn,$sql);
                                while($row=mysqli_fetch_array($result)){
                                    ?>
                                    <option  value="<?php echo $row["depName"]?>"><?php echo $row["depName"]?></option>
                                <?php } ?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group"> 
                    <label class="col-md-4 control-label">Выберите юриста</label>
                    <div class="col-md-4 selectContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-list"></i></span>
                            <select name="lawyer_name"  class="form-control">
                                <option selected value="">Выберите юриста</option>
                                <?php 
                                include "config.php";
                                '<select name="lawyer_name" class="form-control">
                                    <option value="">Выберите юриста</option>';
                                    // Получить список имен юристов из таблицы registration
                                    $sql_lawyers = "SELECT usrName FROM registration WHERE roleid = 2";
                                    $result_lawyers = mysqli_query($conn, $sql_lawyers);
                                    while ($lawyer = mysqli_fetch_assoc($result_lawyers)) {
                                        echo '<option value="'.$lawyer['usrName'].'">'.$lawyer['usrName'].'</option>';
                                    }
                                 
                                 echo '</select>'?>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label">Выберите лицо <span style="color: red;">*</span></label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <input type="checkbox" id="legal_entity" name="legal_entity" onclick="checkLegalEntity()">
                            <label for="legal_entity">Юридическое лицо</label><br>
                            <input type="checkbox" id="individual" name="individual" onclick="checkIndividual()" checked>
                            <label for="individual">Физическое лицо</label><br><br>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label">Номер телефона <span style="color: red;">*</span></label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="glyphicon glyphicon-earphone"></i></span>
                            <input name="phone" placeholder="(+7)" class="form-control" type="text"required>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label">Опишите вашу проблему <span style="color: red;">*</span></label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <textarea name="problem_description" placeholder="Опишите вашу проблему" class="form-control" rows="5" style='width: 302px; height: 110px;'></textarea>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label">Здесь вы можете загрузить дополнительную информацию</label>  
                    <div class="col-md-4 inputGroupContainer">
                        <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-camera"></i></span>
                            <div class="control-group">
                                <input type="file"  name="lawyer_photograph"/>
                                <p class="help-block text-danger"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <input type="submit" name="lawSubmit" value="Отправить заявку" class="button">
                <div class="homem"  >
                  <a href="home.php" class="button"  >На главную </a>  
                </div>
                
            </fieldset>
        </form>
    </div>
</body>
</html>

<style>
body {
    overflow-y: auto;
    display: flex;
    justify-content: center;
    align-items: center;
    min-height: 100vh;
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    overflow-x: hidden; /* Чтобы избежать горизонтальной прокрутки */
    overflow-y: auto; /* Добавляем вертикальную прокрутку */
}


.homem{
    margin-top: 15px;
    margin-left: 35px;
}

.container{
margin-top: 2%;
width:70%;
}
@mixin sp-layout {
  @media screen and (max-width: 750px) {
    @content;
  }
}



.button {
    margin-left:35%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;

    
}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}

.profile-pic {
    width: 200px;
    max-height: 200px;
    display: inline-block;
}

.file-upload {
    display: none;
}
.circle {
    border-radius: 100% !important;
    overflow: hidden;
    width: 128px;
    height: 128px;
    border: 2px solid rgba(255, 255, 255, 0.2);
    position: absolute;
    top: 72px;
}
img {
    max-width: 100%;
    height: auto;
}
.p-image {
  position: absolute;
  top: 167px;
  right: 30px;
  color: #666666;
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.p-image:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
}
.upload-button {
  font-size: 1.2em;
}

.upload-button:hover {
  transition: all .3s cubic-bezier(.175, .885, .32, 1.275);
  color: #999;
}
</style>
<script>
    $(document).ready(function() {

    
var readURL = function(input) {
    if (input.files && input.files[0]) {
        var reader = new FileReader();

        reader.onload = function (e) {
            $('.profile-pic').attr('src', e.target.result);
        }

        reader.readAsDataURL(input.files[0]);
    }
}


$(".file-upload").on('change', function(){
    readURL(this);
});

$(".upload-button").on('click', function() {
   $(".file-upload").click();
});
});
</script>
