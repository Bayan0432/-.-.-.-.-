
<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Профиль юриста</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: iPortfolio - v3.9.1
  * Template URL: https://bootstrapmade.com/iportfolio-bootstrap-portfolio-websites-template/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>
<?php
        include "config.php";

        if(isset($_GET['usrName'])) {
            $request_id = $_GET['usrName'];
            $sql = "SELECT * FROM appointments WHERE usrName = '$request_id'";
            $result = mysqli_query($conn, $sql);

            if(mysqli_num_rows($result) == 1) {
                $row = mysqli_fetch_assoc($result);
                echo '
                <section id="app" class="contact">
                <div class="container">
          
                  <div class="section-title">
                    <h2 id="bookApp"> Формирование консультации </h2>
                  </div>                <form method="post" class="php-email-form">
                    <div class="row">
                        <div class="form-group col-md-6">
                        <label for="name">Ваше имя</label>
                        <input type="text" name="name" class="form-control" id="name" name="name"  required  value="' . $row['usrName'] . '"></div>
                        <div class="form-group col-md-6">
                        <label for="name">Ваш Email</label>
                        <input type="email" class="form-control" name="email" id="email"   required value="' . $row['email'] . '">
                        </div>
                        <div class="form-group">
                        <label for="name">Дата</label>
                        <input  class="form-control border-0 p-4 datetimepicker-input" placeholder="Select Date" data-target="#date" data-toggle="datetimepicker" name="date" value="' . $row['date'] . '" >
                    </div>
                    <div class="form-group">
                        <label for="name">Время</label>
                        <input  class="form-control border-0 p-4 datetimepicker-input"  name="time" value="' . $row['time'] . '" >
                    </div>
                    <div class="form-group">
                        <label for="name">Имя юриста</label>
                        <input type="text" class="form-control" name="lawname" id="subject" readonly required value="' . $row['lawname'] . '">
                    </div>
                    <div class="form-group">
                    <label for="name">Услуга</label>
                    <input type="text" class="form-control" name="dep" id="subject" readonly  required  value="' . $row['service'] . '">
                    </div>
                </div>
                <div class="bu"><a href="userPanel.php#Принятыезаявки" class="button" style="
                padding: 12px 128px;
                border-radius: 5px;
            "> Назад</a></div>
            </form>
      </div>
      </section><!-- End Contact Section -->';

            } else {
                echo "Заявка не найдена.";
            }
        } else {
            echo "Идентификатор заявки не указан.";
        }

        mysqli_close($conn);
        ?>




    <style>
      .bu{
        margin-top:10px;
    }
        .button {
    margin-left:35%;
	border-radius: 20px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 45px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;

}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);

}
#hero {
  width: 100%;
  height: 49vh;
  background:  top center;
  background-size: cover;
}

#hero:before {
  content: "";
  background: 0;
  position: absolute;
  bottom: 0;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1;
}
        </style>