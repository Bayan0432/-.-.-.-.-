<?php
$server="localhost"; 
$username="root"; 
$password=""; 
$db="eproject"; 

$conn = mysqli_connect($server,$username,$password,$db);
// if(!$conn){
//     die(mysqli_error($conn));
// }
// else{
//     echo"Connection has been established";
// }
?>