<?php

include "config.php";
$id = $_GET['id'];
$sql = "UPDATE ConsultationRequests  set Agreements = 'Подтверждено' where id = '$id'";
$result=mysqli_query($conn,$sql);
header("location:userPanel.php");
?>