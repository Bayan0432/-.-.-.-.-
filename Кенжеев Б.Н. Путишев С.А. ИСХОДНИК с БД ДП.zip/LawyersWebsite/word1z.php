<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Снятие запрета со счета физического лица.docx');

// Обработка данных из формы
$name = $_POST['name'];
$date = $_POST['date'];
$mestoroj = $_POST['mestoroj'];
$adressreg = $_POST['adressreg'];
$iin = $_POST['iin'];
$nomeryd = $_POST['nomeryd'];
$kemvidan = $_POST['kemvidan'];
$adress = $_POST['adress'];
$numtel = $_POST['numtel'];
$elpohta = $_POST['elpohta'];
$namesud = $_POST['namesud'];
$adresssud = $_POST['adresssud'];
$prichina = $_POST['prichina'];
$documents = $_POST['documents'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('name', $name);
$document->setValue('date', $date);
$document->setValue('mestoroj', $mestoroj);
$document->setValue('adressreg', $adressreg);
$document->setValue('iin', $iin);
$document->setValue('nomeryd', $nomeryd);
$document->setValue('kemvidan', $kemvidan);
$document->setValue('adress', $adress);
$document->setValue('numtel', $numtel);
$document->setValue('elpohta', $elpohta);
$document->setValue('namesud', $namesud);
$document->setValue('adresssud', $adresssud);
$document->setValue('prichina', $prichina);
$document->setValue('documents', $documents);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Снятие запрета со счета физического лица' . $name . '.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
