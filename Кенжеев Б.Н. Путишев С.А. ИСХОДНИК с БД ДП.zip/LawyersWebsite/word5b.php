<?php
require_once 'vendor/autoload.php';

// Создаем экземпляр TemplateProcessor и загружаем шаблон
$document = new \PhpOffice\PhpWord\TemplateProcessor('Аппеляционная жалоба (юридическое лицо).docx');

// Обработка данных из формы
$namesud = $_POST['namesud'];
$nameurlic = $_POST['nameurlic'];
$addressurlic = $_POST['addressurlic'];
$nameistca = $_POST['nameistca'];
$nameotvet = $_POST['nameotvet'];
$trebov = $_POST['trebov'];
$reshenosud = $_POST['reshenosud'];
$osnovania = $_POST['osnovania'];
$dolzno = $_POST['dolzno'];
$date = $_POST['date'];
$lawyer_id = $_POST['lawyer_id'];
$lawyer_name = $_POST['lawyer_name'];

// Замена значений в шаблоне
$document->setValue('namesud', $namesud);
$document->setValue('nameurlic', $nameurlic);
$document->setValue('addressurlic', $addressurlic);
$document->setValue('nameistca', $nameistca);
$document->setValue('nameotvet', $nameotvet);
$document->setValue('trebov', $trebov);
$document->setValue('reshenosud', $reshenosud);
$document->setValue('osnovania', $osnovania);
$document->setValue('dolzno', $dolzno);
$document->setValue('date', $date);

// Создаем название файла с учетом имени пользователя
$outputFileName = 'Апелляционная_жалоба_' . $nameurlic . '_юр_full.docx';
$outputFilePath = 'files/' . $outputFileName; // Assuming you have an "uploads" directory

// Save the document
$document->saveAs($outputFilePath);

// Подключение к базе данных
$connection = mysqli_connect("localhost", "root", "", "eproject");

// Проверка подключения
if ($connection === false) {
    die("Ошибка подключения: " . mysqli_connect_error());
}

// SQL запрос для вставки ссылки на файл в базу данных
$sql = "INSERT INTO generated_files (filename, file_link, lawyer_name, lawyer_id) VALUES ('$outputFileName', '$outputFilePath', '$lawyer_name', '$lawyer_id')";

// Выполнение запроса
if (mysqli_query($connection, $sql)) {
    echo "Файл успешно сохранен в базе данных.";
} else {
    echo "Ошибка: " . $sql . "<br>" . mysqli_error($connection);
}

// Закрываем соединение с базой данных
mysqli_close($connection);

// Перенаправление обратно на страницу формы
header('Location: lawyerPanel.php');
exit;
?>
