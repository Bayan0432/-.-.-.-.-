<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Генерация категории Снятие запрета со счета юридического лица (для долга перед банком)</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f2f2f2;
        }

        form {
            width: 400px; /* Ширина формы */
            padding: 20px;
            border: 1px solid #ccc;
            border-radius: 10px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            margin-top: 20px; /* Отступ сверху для формы */
            margin: 0 auto; /* Центрирование формы */
        }

        input[type="text"],
        input[type="number"],
        textarea,
        input[type="date"] {
            width: calc(100% - 20px);
            height: 40px;
            margin-bottom: 15px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            font-size: 16px;
            box-sizing: border-box;
        }

        textarea {
            height: 100px;
            resize: vertical;
        }

        button {
            width: 100%;
            height: 50px;
            background-color: #afa939; /* Зеленый цвет кнопки */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 18px;
            transition: background-color 0.3s ease;
            padding: 10px 20px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 16px;
            margin-top: 10px; /* Отступ сверху для кнопки */
            cursor: pointer;
        }

        button:hover {
            background-color: #4CAF50; /* Зеленый цвет кнопки при наведении */
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
            color: #333;
            margin-top: 50px; /* Отступ сверху для заголовка */
        }
    </style>
</head>
<body>
<?php
include "config.php";
session_start();

// Проверяем роль пользователя
if($_SESSION['role'] == 2) {
    $user_id = $_SESSION['uId'];
    $user_name = $_SESSION['username'];

}
?>
    <h1>Генерация категории Снятие запрета со счета юридического лица (для долга перед банком)</h1>
    <form action="word2z.php" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="lawyer_id" value="<?php echo $user_id; ?>">
    <input type="hidden" name="lawyer_name" value="<?php echo $user_name; ?>">
    <input type="text" name="namebank" placeholder="Наименование банка">
    <input type="text" name="adresbank" placeholder="Адрес банка">
    <input type="date" name="date" placeholder="Дата">
    <input type="text" name="numchet" placeholder="Номер корпоративного счета">
    <textarea name="prichinazapr" placeholder="Причина запрета"></textarea>
    <input type="text" name="name" placeholder="Наименование юридического лица">
    <input type="text" name="uradress" placeholder="Юридический адрес">
    <input type="text" name="iin" placeholder="ИНН">
    <input type="text" name="ogrn" placeholder="ОГРН">
    <input type="text" name="tel" placeholder="Контактный телефон">
    <input type="text" name="lico" placeholder="Ваша должность">
    <button type="submit">Отправить</button>
    <div class="bu"><a href="generate.php" class="button">Назад</a></div>
    
    
</form>
</body>
</html>
<style>
    .bu{
        margin-top:10px;
    }
    .button {
	border-radius: 5px;
	border: 1px solid #FF4B2B;
	color: #FFFFFF;
	font-size: 12px;
	font-weight: bold;
	padding: 12px 175px;
	letter-spacing: 1px;
	text-transform: uppercase;
	transition: transform 80ms ease-in;
    background-color: #FF4B2B;
    margin-top: 20px;
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}

.button:active {
	transform: scale(0.95);
}

.button:focus {
	outline: none;
}

.button:hover{
    background: radial-gradient(ellipse at bottom, #0d1d31 0%, #0c0d13 100%);
    text-decoration: none; /* Убираем подчеркивание */
    color: #FFFFFF;
}
</style>